import {
  UserCyberProfile,
  AnomalyVector,
  RiskCalculationBreakdown,
  DigitalTwinNode,
  DigitalTwinEdge,
  ActivityEvent,
  GamificationMission,
  SyntheticDatasetRow,
} from "../types";

export const initialProfile: UserCyberProfile = {
  userName: "Rohan Sharma",
  userRole: "Undergraduate Student (Computer Science & AI)",
  normalLocations: ["Hyderabad (Gachibowli)", "Tech Campus WiFi (Eduroam)", "Home Fiber Net"],
  knownDevices: [
    {
      id: "dev-1",
      name: "MacBook Air M2 (macOS 15)",
      type: "laptop",
      lastSeen: "10 mins ago",
      trusted: true,
      ipRange: "103.211.x.x (Airtel Broadband)",
    },
    {
      id: "dev-2",
      name: "Pixel 8 Pro (Android 15)",
      type: "mobile",
      lastSeen: "Just now",
      trusted: true,
      ipRange: "49.37.x.x (Jio 5G)",
    },
  ],
  typicalActiveHours: {
    start: 9, // 09:00 AM
    end: 23, // 11:00 PM
  },
  commonServices: ["University Portal", "Gmail", "GitHub", "Google Drive", "SBI Online Banking"],
  privacyMode: true, // Local-First Privacy Mode active by default
  overallRiskScore: 18, // Normal baseline: LOW risk
  lastEvaluationTime: "Just now",
  categoryScores: {
    identity: 88, // 0 to 100 health
    device: 92,
    account: 80,
    network: 85,
  },
};

export const samplePhishingTemplates = [
  {
    id: "hackathon-sample",
    name: "College Account Deactivation Warning (Prompt Sample)",
    type: "email",
    sender: "helpdesk@university-account-support.online",
    url: "http://college-login-security.example/auth-verify",
    content: `URGENT: Your college account will be disabled today.
Click here immediately to verify your password:
http://college-login-security.example

Failure to authenticate within 2 hours will result in permanent suspension of course portal and examination registration.
Security Administration Team`,
  },
  {
    id: "bank-otp",
    name: "Urgent Bank KYC & OTP Trap",
    type: "sms",
    sender: "+91 98210-XX-SBI",
    url: "https://sbi-kyc-update-alert.biz/pan",
    content: `Dear Customer, Your SBI NetBanking access is temporarily blocked due to missing PAN verification. Update immediately to prevent INR 1,500 penalty. Click: https://sbi-kyc-update-alert.biz/pan and submit OTP received.`,
  },
  {
    id: "job-offer",
    name: "AI-Generated WhatsApp Student Job Scam",
    type: "message",
    sender: "Global Recruitment HR (+44 7700 900123)",
    url: "https://telegram.me/instant_task_crypto_earn",
    content: `Greetings! We noticed your outstanding profile on the student portal. Earn $250-$800 daily by simply rating apps for 30 minutes from home. No experience needed. Join our Telegram channel right now to claim your $50 sign-up bonus today!`,
  },
  {
    id: "legit-newsletter",
    name: "Legitimate Campus Seminar Announcement (Safe Control)",
    type: "email",
    sender: "academics@univ.edu.in",
    url: "https://univ.edu.in/seminars/ai-safety-2026",
    content: `Dear Students,
The Department of Computer Science invites you to the Annual AI Safety Symposium this Friday at 4:00 PM in Auditorium 2.
Registration is free on the official campus portal. No account credentials or fees are required.
Best regards,
Academic Affairs Committee`,
  },
];

export const sampleSyntheticDataset: SyntheticDatasetRow[] = [
  { login_hour: 19, location_change: 0, new_device: 0, failed_attempts: 0, data_download_mb: 20, password_change: 0, risk_label: "normal", anomaly_score: -0.12 },
  { login_hour: 3, location_change: 1, new_device: 1, failed_attempts: 5, data_download_mb: 800, password_change: 1, risk_label: "suspicious", anomaly_score: 0.88 },
  { login_hour: 21, location_change: 0, new_device: 0, failed_attempts: 1, data_download_mb: 30, password_change: 0, risk_label: "normal", anomaly_score: -0.09 },
  { login_hour: 2, location_change: 1, new_device: 1, failed_attempts: 8, data_download_mb: 1200, password_change: 1, risk_label: "suspicious", anomaly_score: 0.94 },
  { login_hour: 14, location_change: 0, new_device: 0, failed_attempts: 0, data_download_mb: 15, password_change: 0, risk_label: "normal", anomaly_score: -0.15 },
  { login_hour: 11, location_change: 0, new_device: 0, failed_attempts: 1, data_download_mb: 45, password_change: 0, risk_label: "normal", anomaly_score: -0.05 },
  { login_hour: 4, location_change: 1, new_device: 1, failed_attempts: 4, data_download_mb: 650, password_change: 0, risk_label: "suspicious", anomaly_score: 0.79 },
  { login_hour: 16, location_change: 0, new_device: 0, failed_attempts: 0, data_download_mb: 35, password_change: 0, risk_label: "normal", anomaly_score: -0.11 },
  { login_hour: 22, location_change: 0, new_device: 0, failed_attempts: 0, data_download_mb: 80, password_change: 0, risk_label: "normal", anomaly_score: -0.03 },
  { login_hour: 1, location_change: 1, new_device: 1, failed_attempts: 6, data_download_mb: 950, password_change: 1, risk_label: "suspicious", anomaly_score: 0.91 },
];

export const initialDigitalTwinNodes: DigitalTwinNode[] = [
  { id: "node-user", label: "Rohan's Identity", category: "account", status: "secure", details: "Zero-trust verified baseline profile", x: 400, y: 70 },
  { id: "node-gmail", label: "University Gmail", category: "account", status: "secure", details: "OAuth 2.0 / SSO single sign-on hub", x: 220, y: 170, mfaEnabled: true },
  { id: "node-bank", label: "Bank Account", category: "account", status: "secure", details: "NetBanking with SMS OTP (Phishing Vulnerable)", x: 580, y: 170, mfaEnabled: false },
  { id: "node-github", label: "GitHub Account", category: "account", status: "secure", details: "Contains private course repos & PAT tokens", x: 400, y: 190, mfaEnabled: true },
  { id: "node-mac", label: "MacBook Air (Known)", category: "device", status: "secure", details: "TouchID enabled, FileVault disk encryption", x: 160, y: 310 },
  { id: "node-phone", label: "Pixel 8 Pro (Known)", category: "device", status: "secure", details: "Biometric Passkey enabled", x: 320, y: 310 },
  { id: "node-untrusted-dev", label: "Foreign Device (Tor/VPN)", category: "device", status: "warning", details: "Unknown browser fingerprint & IP", x: 650, y: 310 },
  { id: "node-drive", label: "Cloud Storage", category: "app", status: "secure", details: "Contains academic coursework & ID scans", x: 180, y: 440 },
  { id: "node-ssh", label: "SSH Keys & Secrets", category: "sensitive_data", status: "secure", details: "Private campus lab server access keys", x: 380, y: 440 },
  { id: "node-passwords", label: "Browser Vault", category: "sensitive_data", status: "secure", details: "14 saved passwords, 3 reused credentials", x: 580, y: 440 },
];

export const initialDigitalTwinEdges: DigitalTwinEdge[] = [
  { id: "e1", source: "node-user", target: "node-gmail", label: "Primary SSO" },
  { id: "e2", source: "node-user", target: "node-bank", label: "Personal Financial" },
  { id: "e3", source: "node-user", target: "node-github", label: "Dev Identity" },
  { id: "e4", source: "node-gmail", target: "node-drive", label: "Syncs to Drive" },
  { id: "e5", source: "node-gmail", target: "node-github", label: "Password Recovery" },
  { id: "e6", source: "node-mac", target: "node-gmail", label: "Authorized Session" },
  { id: "e7", source: "node-phone", target: "node-gmail", label: "Authorized Session" },
  { id: "e8", source: "node-github", target: "node-ssh", label: "Deploy keys" },
  { id: "e9", source: "node-mac", target: "node-passwords", label: "Keychain sync" },
  { id: "e10", source: "node-untrusted-dev", target: "node-gmail", label: "Unauthorized attempt", activeRisk: true },
];

export const initialActivityEvents: ActivityEvent[] = [
  {
    id: "act-1",
    timestamp: "Today, 19:30",
    event: "Successful Login",
    location: "Hyderabad, Telangana (Airtel)",
    device: "MacBook Air M2",
    riskScore: 8,
    status: "normal",
    details: "Known device, usual location, standard active study hours.",
  },
  {
    id: "act-2",
    timestamp: "Today, 14:15",
    event: "Campus Wi-Fi Connection",
    location: "Eduroam Hub (Campus Gachibowli)",
    device: "Pixel 8 Pro",
    riskScore: 12,
    status: "normal",
    details: "WPA2 Enterprise certificate verified by University IT.",
  },
  {
    id: "act-3",
    timestamp: "Yesterday, 21:05",
    event: "Code Push & Repo Sync",
    location: "Hyderabad, Telangana",
    device: "MacBook Air M2",
    riskScore: 10,
    status: "normal",
    details: "SSH ed25519 signature validated on GitHub.",
  },
];

export const initialMissions: GamificationMission[] = [
  {
    id: "m-1",
    title: "Enforce Phishing-Resistant MFA",
    category: "MFA",
    xp: 150,
    description: "Replace SMS OTP with FIDO2 / WebAuthn biometric passkey on University & Bank accounts (CISA recommendation).",
    completed: false,
    actionText: "Enable FIDO2 Passkey",
  },
  {
    id: "m-2",
    title: "Analyze Suspicious College Warning Email",
    category: "Phishing Quiz",
    xp: 100,
    description: "Run CyberShadow AI scanner on an urgent deactivation threat and inspect the fake domain.",
    completed: false,
    actionText: "Scan Phishing Sample",
  },
  {
    id: "m-3",
    title: "Audit Excessive Third-Party App Permissions",
    category: "Permissions",
    xp: 80,
    description: "Review third-party OAuth apps connected to your Google workspace that haven't been used in 30 days.",
    completed: true,
    actionText: "Permissions Audited",
  },
  {
    id: "m-4",
    title: "Eliminate Reused Password in Browser Vault",
    category: "Passwords",
    xp: 120,
    description: "Generate an isolated 24-character cryptographic password for your student portal.",
    completed: false,
    actionText: "Rotate Weak Credential",
  },
  {
    id: "m-5",
    title: "Verify Local-First Privacy Boundaries",
    category: "Privacy",
    xp: 75,
    description: "Inspect the zero-knowledge metadata engine and confirm no raw passwords or private chats are stored.",
    completed: true,
    actionText: "Review Privacy Ledger",
  },
];

/**
 * Calculates the exact formula from the problem statement:
 * RiskScore = 0.25*L + 0.20*D + 0.20*F + 0.15*T + 0.20*B
 */
export function calculateCyberRiskScore(v: AnomalyVector): RiskCalculationBreakdown {
  const L_val = Math.min(100, Math.max(0, v.locationChangeScore));
  const D_val = Math.min(100, Math.max(0, v.deviceScore));
  const F_val = Math.min(100, Math.max(0, v.failedLoginScore));
  const T_val = Math.min(100, Math.max(0, v.unusualTimeScore));
  const B_val = Math.min(100, Math.max(0, v.abnormalBehaviorScore));

  const weightedScore = 0.25 * L_val + 0.20 * D_val + 0.20 * F_val + 0.15 * T_val + 0.20 * B_val;
  const finalScore = Math.round(weightedScore);

  let riskLevel: "Low" | "Moderate" | "High" | "Critical" = "Low";
  if (finalScore >= 76) riskLevel = "Critical";
  else if (finalScore >= 51) riskLevel = "High";
  else if (finalScore >= 26) riskLevel = "Moderate";
  else riskLevel = "Low";

  return {
    finalScore,
    riskLevel: riskLevel as any,
    components: {
      L: { label: "Unusual Location", weight: 0.25, rawScore: L_val, weightedScore: Math.round(0.25 * L_val * 10) / 10 },
      D: { label: "Unknown Device", weight: 0.20, rawScore: D_val, weightedScore: Math.round(0.20 * D_val * 10) / 10 },
      F: { label: "Failed Login Attempts", weight: 0.20, rawScore: F_val, weightedScore: Math.round(0.20 * F_val * 10) / 10 },
      T: { label: "Unusual Time", weight: 0.15, rawScore: T_val, weightedScore: Math.round(0.15 * T_val * 10) / 10 },
      B: { label: "Abnormal Behavior", weight: 0.20, rawScore: B_val, weightedScore: Math.round(0.20 * B_val * 10) / 10 },
    },
  };
}
