export type RiskLevel = "Low" | "Medium" | "High" | "Critical";

export interface UserCyberProfile {
  userName: string;
  userRole: string; // e.g. "Computer Science Undergraduate"
  normalLocations: string[]; // ["Hyderabad, India", "Campus Hostel", "Home WiFi"]
  knownDevices: {
    id: string;
    name: string;
    type: "laptop" | "mobile" | "tablet" | "workstation";
    lastSeen: string;
    trusted: boolean;
    ipRange: string;
  }[];
  typicalActiveHours: {
    start: number; // e.g. 9
    end: number; // e.g. 23
  };
  commonServices: string[];
  privacyMode: boolean; // Local-first privacy mode
  overallRiskScore: number; // 0 - 100
  lastEvaluationTime: string;
  categoryScores: {
    identity: number;
    device: number;
    account: number;
    network: number;
  };
}

export interface AnomalyVector {
  loginHour: number; // 0-23
  locationName: string;
  distanceKm: number;
  locationChangeScore: number; // L: 0-100
  deviceName: string;
  isNewDevice: boolean;
  deviceScore: number; // D: 0-100
  failedAttempts: number;
  failedLoginScore: number; // F: 0-100
  unusualTimeScore: number; // T: 0-100
  dataDownloadMB: number;
  passwordChangeAttempt: boolean;
  unusualFileAccess: boolean;
  abnormalBehaviorScore: number; // B: 0-100
}

export interface RiskCalculationBreakdown {
  finalScore: number;
  riskLevel: RiskLevel;
  components: {
    L: { label: "Unusual Location", weight: 0.25, rawScore: number, weightedScore: number };
    D: { label: "Unknown Device", weight: 0.20, rawScore: number, weightedScore: number };
    F: { label: "Failed Login Attempts", weight: 0.20, rawScore: number, weightedScore: number };
    T: { label: "Unusual Time", weight: 0.15, rawScore: number, weightedScore: number };
    B: { label: "Abnormal Behavior", weight: 0.20, rawScore: number, weightedScore: number };
  };
}

export interface ExplainableAlert {
  id: string;
  timestamp: string;
  title: string;
  riskScore: number;
  riskLevel: RiskLevel;
  threatVector: string;
  confidence: number;
  reasons: string[];
  explanationText: string;
  actions: {
    priority: "Urgent" | "High" | "Medium" | "Low";
    title: string;
    description: string;
    applied?: boolean;
  }[];
  blastRadiusNodes?: string[];
}

export interface PhishingIndicator {
  flag: string;
  severity: "low" | "medium" | "high" | "critical";
  explanation: string;
}

export interface PhishingAnalysis {
  riskLevel: RiskLevel;
  riskScore: number;
  summary: string;
  indicators: PhishingIndicator[];
  recommendedActions: string[];
  shadowSimulation: {
    permissionsAtRisk: string[];
    affectedAccounts: string[];
    domainReputation: string;
    potentialBlastRadius: string;
    mitigationControl: string;
  };
}

export interface DigitalTwinNode {
  id: string;
  label: string;
  category: "account" | "device" | "app" | "network" | "sensitive_data";
  status: "secure" | "warning" | "compromised";
  details: string;
  x: number;
  y: number;
  mfaEnabled?: boolean;
}

export interface DigitalTwinEdge {
  id: string;
  source: string;
  target: string;
  label?: string;
  activeRisk?: boolean;
}

export interface ActivityEvent {
  id: string;
  timestamp: string;
  event: string;
  location: string;
  device: string;
  riskScore: number;
  status: "normal" | "suspicious" | "critical";
  details: string;
}

export interface GamificationMission {
  id: string;
  title: string;
  category: "MFA" | "Phishing Quiz" | "Permissions" | "Passwords" | "Privacy";
  xp: number;
  description: string;
  completed: boolean;
  actionText: string;
}

export interface SyntheticDatasetRow {
  login_hour: number;
  location_change: number; // 0 or 1
  new_device: number; // 0 or 1
  failed_attempts: number;
  data_download_mb: number;
  password_change: number; // 0 or 1
  risk_label: "normal" | "suspicious";
  anomaly_score: number; // simulated Isolation Forest score
}
