import React, { useState, useEffect, useMemo } from "react";
import {
  Activity,
  ShieldCheck,
  ShieldAlert,
  AlertTriangle,
  PlayCircle,
  Sparkles,
  Search,
  BookOpen,
  Trophy,
  Layers,
  EyeOff,
  UserCheck,
  RefreshCw,
  ExternalLink,
} from "lucide-react";
import { Header } from "./components/Header";
import { RiskScoreGauge } from "./components/RiskScoreGauge";
import { RecentAlerts } from "./components/RecentAlerts";
import { BehaviorTimeline } from "./components/BehaviorTimeline";
import { DigitalTwinGraph } from "./components/DigitalTwinGraph";
import { AnomalyEngine } from "./components/AnomalyEngine";
import { PhishingScanner } from "./components/PhishingScanner";
import { ShadowSimulator } from "./components/ShadowSimulator";
import { SecurityCoach } from "./components/SecurityCoach";
import { GamificationView } from "./components/GamificationView";
import { PrivacyModal } from "./components/PrivacyModal";
import { HackathonDemoModal } from "./components/HackathonDemoModal";
import {
  UserCyberProfile,
  AnomalyVector,
  ExplainableAlert,
  DigitalTwinNode,
  DigitalTwinEdge,
  ActivityEvent,
  GamificationMission,
  PhishingAnalysis,
} from "./types";
import {
  initialProfile,
  calculateCyberRiskScore,
  initialDigitalTwinNodes,
  initialDigitalTwinEdges,
  initialActivityEvents,
  initialMissions,
  samplePhishingTemplates,
} from "./data/cyberDefaults";

export default function App() {
  // Navigation tab state
  const [currentTab, setCurrentTab] = useState<string>("dashboard");

  // User Profile State
  const [profile, setProfile] = useState<UserCyberProfile>(() => {
    const saved = localStorage.getItem("cybershadow_profile");
    return saved ? JSON.parse(saved) : initialProfile;
  });

  // Behavioral Anomaly Vector State (L, D, F, T, B)
  const [vector, setVector] = useState<AnomalyVector>({
    loginHour: 19,
    locationName: "Hyderabad, Telangana (Airtel)",
    distanceKm: 0,
    locationChangeScore: 5,
    deviceName: "MacBook Air M2 (Known)",
    isNewDevice: false,
    deviceScore: 0,
    failedAttempts: 0,
    failedLoginScore: 0,
    unusualTimeScore: 5,
    dataDownloadMB: 20,
    passwordChangeAttempt: false,
    unusualFileAccess: false,
    abnormalBehaviorScore: 5,
  });

  // Calculate dynamic formula breakdown
  const breakdown = useMemo(() => calculateCyberRiskScore(vector), [vector]);

  // Sync profile score with calculated breakdown
  useEffect(() => {
    setProfile((prev) => ({
      ...prev,
      overallRiskScore: breakdown.finalScore,
    }));
  }, [breakdown.finalScore]);

  // Save profile to local storage (Local-First Privacy)
  useEffect(() => {
    if (profile.privacyMode) {
      localStorage.setItem("cybershadow_profile", JSON.stringify(profile));
    }
  }, [profile]);

  // Alerts State
  const [alerts, setAlerts] = useState<ExplainableAlert[]>([
    {
      id: "alert-baseline-1",
      timestamp: "10 mins ago",
      title: "Elevated Risk: Foreign Device Login Attempt",
      riskScore: 87,
      riskLevel: "Critical",
      threatVector: "Impossible Travel & Credential Stuffing",
      confidence: 94,
      reasons: [
        "Device has never been seen in your verified hardware cluster (Windows NT / Tor Exit Node)",
        "Login time (03:00 AM) is outside your learned 09:00 - 23:00 circadian pattern",
        "Location differs by 5,800 km from your active baseline (Bucharest, Romania vs. Hyderabad)",
        "Five failed login attempts occurred immediately prior to authorization",
        "Sudden password change attempted within two minutes of access",
      ],
      explanationText:
        "This login occurred from an unrecognized device at an unusual hour and from a location 5,800 km away from your usual activity. A password change was attempted two minutes later following multiple failed credentials.",
      actions: [
        {
          priority: "Urgent",
          title: "Verify the login immediately",
          description: "Confirm whether you were traveling or using a foreign proxy tunnel.",
        },
        {
          priority: "Urgent",
          title: "Change the account password",
          description: "Rotate compromised credentials from a trusted verified personal device.",
        },
        {
          priority: "High",
          title: "Enable phishing-resistant MFA",
          description: "Adopt CISA-recommended FIDO2 / WebAuthn biometric passkeys to block replay attacks.",
        },
        {
          priority: "Medium",
          title: "Review active sessions & revoke foreign tokens",
          description: "Force kill unauthorized session tokens on foreign endpoints.",
        },
      ],
    },
  ]);

  // Digital Twin Nodes & Edges
  const [nodes, setNodes] = useState<DigitalTwinNode[]>(initialDigitalTwinNodes);
  const [edges, setEdges] = useState<DigitalTwinEdge[]>(initialDigitalTwinEdges);

  // Timeline Activity Events
  const [events, setEvents] = useState<ActivityEvent[]>(initialActivityEvents);

  // Gamification Missions
  const [missions, setMissions] = useState<GamificationMission[]>(initialMissions);

  // Phishing Analysis Result
  const [phishingResult, setPhishingResult] = useState<PhishingAnalysis | null>(null);

  // Loading and Modal states
  const [isScanningPhishing, setIsScanningPhishing] = useState<boolean>(false);
  const [isAnalyzingAlert, setIsAnalyzingAlert] = useState<boolean>(false);
  const [isDemoModalOpen, setIsDemoModalOpen] = useState<boolean>(false);
  const [isPrivacyModalOpen, setIsPrivacyModalOpen] = useState<boolean>(false);

  // Handle Vector Updates
  const handleVectorChange = (updated: Partial<AnomalyVector>) => {
    setVector((prev) => ({ ...prev, ...updated }));
  };

  // Synthesize Explainable AI Alert using server-side Gemini or fallback
  const handleTriggerExplainableAlert = async () => {
    setIsAnalyzingAlert(true);
    try {
      const res = await fetch("/api/gemini/explain-alert", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          loginHour: vector.loginHour,
          location: vector.locationName,
          distanceKm: vector.distanceKm,
          device: vector.deviceName,
          failedAttempts: vector.failedAttempts,
          dataDownloadMB: vector.dataDownloadMB,
          passwordChangeAttempted: vector.passwordChangeAttempt,
          calculatedScore: breakdown.finalScore,
        }),
      });
      const data = await res.json();
      if (data.success && data.data) {
        const newAlert: ExplainableAlert = {
          id: "alert-" + Date.now(),
          timestamp: "Just now",
          title: data.data.headline || `Anomaly Event (${breakdown.finalScore}/100)`,
          riskScore: breakdown.finalScore,
          riskLevel: breakdown.riskLevel,
          threatVector: data.data.threatVector || "Behavioral Deviation",
          confidence: data.data.confidence || 90,
          reasons: data.data.reasons || ["Unusual circadian login time", "Geographic divergence"],
          explanationText: data.data.explanationText || "Deviation from baseline profile detected.",
          actions: data.data.prioritizedActions || [
            { priority: "Urgent", title: "Verify Session", description: "Audit device origin." },
            { priority: "High", title: "Rotate Credentials", description: "Change master password." },
          ],
        };

        setAlerts((prev) => [newAlert, ...prev]);

        // Add to timeline
        setEvents((prev) => [
          {
            id: "act-" + Date.now(),
            timestamp: "Just now",
            event: "Anomaly Detected",
            location: vector.locationName,
            device: vector.deviceName,
            riskScore: breakdown.finalScore,
            status: breakdown.finalScore >= 51 ? "critical" : "suspicious",
            details: data.data.explanationText,
          },
          ...prev,
        ]);

        // Switch to dashboard tab so the user sees the generated alert
        setCurrentTab("dashboard");
      }
    } catch (err) {
      console.error("Failed to generate explainable alert:", err);
    } finally {
      setIsAnalyzingAlert(false);
    }
  };

  // Run Phishing Scan using server-side Gemini or fallback
  const handleScanPhishing = async (params: {
    content: string;
    type: string;
    sender: string;
    url: string;
  }) => {
    setIsScanningPhishing(true);
    try {
      const res = await fetch("/api/gemini/analyze-phishing", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(params),
      });
      const data = await res.json();
      if (data.success && data.data) {
        setPhishingResult(data.data);

        // If high risk phishing, add an alert
        if (data.data.riskScore >= 50) {
          const phishingAlert: ExplainableAlert = {
            id: "phish-" + Date.now(),
            timestamp: "Just now",
            title: `Phishing Attempt Flagged: ${params.sender || "Suspicious Message"}`,
            riskScore: data.data.riskScore,
            riskLevel: data.data.riskLevel,
            threatVector: "Credential Harvesting / Domain Spoofing",
            confidence: 96,
            reasons: data.data.indicators.map((i: any) => `${i.flag}: ${i.explanation}`),
            explanationText: data.data.summary,
            actions: data.data.recommendedActions.map((a: string, idx: number) => ({
              priority: idx === 0 ? "Urgent" : idx === 1 ? "High" : "Medium",
              title: a,
              description: "Preventative advisory control.",
            })),
          };
          setAlerts((prev) => [phishingAlert, ...prev]);
        }
      }
    } catch (err) {
      console.error("Phishing scan error:", err);
    } finally {
      setIsScanningPhishing(false);
    }
  };

  // Apply alert remediation action
  const handleApplyAction = (alertId: string, actionIndex: number) => {
    setAlerts((prev) =>
      prev.map((al) => {
        if (al.id === alertId) {
          const updatedActions = [...al.actions];
          updatedActions[actionIndex] = { ...updatedActions[actionIndex], applied: true };
          return { ...al, actions: updatedActions };
        }
        return al;
      })
    );

    // If FIDO2 MFA action applied, lower score and update node
    setNodes((prev) =>
      prev.map((n) =>
        n.id === "node-bank" || n.id === "node-gmail"
          ? { ...n, status: "secure", mfaEnabled: true }
          : n
      )
    );

    // Slightly mitigate risk score vector
    handleVectorChange({
      locationChangeScore: Math.max(5, vector.locationChangeScore - 25),
      failedLoginScore: 0,
      abnormalBehaviorScore: Math.max(5, vector.abnormalBehaviorScore - 30),
      deviceScore: Math.max(0, vector.deviceScore - 40),
    });
  };

  const handleDismissAlert = (alertId: string) => {
    setAlerts((prev) => prev.filter((a) => a.id !== alertId));
  };

  // Digital Twin node compromise simulation
  const handleSimulateNodeCompromise = (nodeId: string) => {
    setNodes((prev) =>
      prev.map((n) => {
        if (n.id === nodeId) return { ...n, status: "compromised" };
        if (n.id === "node-gmail") return { ...n, status: "warning" };
        if (n.id === "node-drive" || n.id === "node-ssh") return { ...n, status: "warning" };
        return n;
      })
    );
    setEdges((prev) =>
      prev.map((e) => (e.source === nodeId || e.target === nodeId ? { ...e, activeRisk: true } : e))
    );
  };

  const handleRestoreAllSafe = () => {
    setNodes(initialDigitalTwinNodes);
    setEdges(initialDigitalTwinEdges);
  };

  // Reset to Baseline
  const handleResetToBaseline = () => {
    setProfile(initialProfile);
    setVector({
      loginHour: 19,
      locationName: "Hyderabad, Telangana (Airtel)",
      distanceKm: 0,
      locationChangeScore: 5,
      deviceName: "MacBook Air M2 (Known)",
      isNewDevice: false,
      deviceScore: 0,
      failedAttempts: 0,
      failedLoginScore: 0,
      unusualTimeScore: 5,
      dataDownloadMB: 20,
      passwordChangeAttempt: false,
      unusualFileAccess: false,
      abnormalBehaviorScore: 5,
    });
    setNodes(initialDigitalTwinNodes);
    setEdges(initialDigitalTwinEdges);
    setAlerts([]);
    localStorage.removeItem("cybershadow_profile");
  };

  // Missions completion toggle
  const handleToggleMission = (id: string) => {
    setMissions((prev) =>
      prev.map((m) => (m.id === id ? { ...m, completed: !m.completed } : m))
    );
  };

  // Execute hackathon demo step
  const handleExecuteDemoStep = (stepNumber: number) => {
    switch (stepNumber) {
      case 1:
        // Load normal baseline
        handleResetToBaseline();
        setCurrentTab("dashboard");
        break;
      case 2:
        // Circadian telemetry
        setCurrentTab("dashboard");
        break;
      case 3:
        // Foreign device anomaly in Bucharest 3 AM
        handleVectorChange({
          loginHour: 3,
          locationName: "Bucharest, Romania (Tor Exit)",
          distanceKm: 5800,
          locationChangeScore: 90,
          deviceName: "Unknown Windows NT / TorBrowser",
          isNewDevice: true,
          deviceScore: 95,
          unusualTimeScore: 85,
        });
        setCurrentTab("anomaly");
        break;
      case 4:
        // Password change & failed attempts surge
        handleVectorChange({
          failedAttempts: 5,
          failedLoginScore: 85,
          passwordChangeAttempt: true,
          abnormalBehaviorScore: 90,
          dataDownloadMB: 800,
        });
        handleSimulateNodeCompromise("node-untrusted-dev");
        setCurrentTab("dashboard");
        break;
      case 5:
        // Upload phishing sample
        setCurrentTab("phishing");
        break;
      case 6:
        // Run AI phishing scanner
        handleScanPhishing({
          content: samplePhishingTemplates[0].content,
          type: "email",
          sender: samplePhishingTemplates[0].sender,
          url: samplePhishingTemplates[0].url,
        });
        setCurrentTab("phishing");
        break;
      case 7:
        // Display explainable alert
        setCurrentTab("dashboard");
        break;
      case 8:
        // Connected account graph
        handleSimulateNodeCompromise("node-untrusted-dev");
        setCurrentTab("digital-twin");
        break;
      case 9:
        // Apply recommended actions
        if (alerts.length > 0) {
          handleApplyAction(alerts[0].id, 0);
          handleApplyAction(alerts[0].id, 1);
          handleApplyAction(alerts[0].id, 2);
        }
        break;
      case 10:
        // End with restored security score
        handleVectorChange({
          locationChangeScore: 5,
          deviceScore: 0,
          failedLoginScore: 0,
          unusualTimeScore: 5,
          abnormalBehaviorScore: 5,
          passwordChangeAttempt: false,
          failedAttempts: 0,
          locationName: "Hyderabad, India",
          deviceName: "MacBook Air (Verified FIDO2)",
        });
        handleRestoreAllSafe();
        setCurrentTab("dashboard");
        break;
      default:
        break;
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans selection:bg-teal-500/30 selection:text-teal-200">
      {/* Header */}
      <Header
        profile={profile}
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        onOpenDemo={() => setIsDemoModalOpen(true)}
        onResetToBaseline={handleResetToBaseline}
        onTogglePrivacy={() =>
          setProfile((p) => ({ ...p, privacyMode: !p.privacyMode }))
        }
        onOpenPrivacyModal={() => setIsPrivacyModalOpen(true)}
      />

      {/* Main Content Area */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {/* TAB 1: MAIN DASHBOARD */}
        {currentTab === "dashboard" && (
          <div className="space-y-6">
            {/* Top Risk Score Gauge & Health Pillars */}
            <RiskScoreGauge
              score={breakdown.finalScore}
              breakdown={breakdown}
              categoryScores={profile.categoryScores}
            />

            {/* Explainable AI Security Alerts */}
            <RecentAlerts
              alerts={alerts}
              onApplyAction={handleApplyAction}
              onDismissAlert={handleDismissAlert}
            />

            {/* Grid: Exposure Graph Preview & Chronological Timeline */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <DigitalTwinGraph
                nodes={nodes}
                edges={edges}
                onSimulateCompromise={handleSimulateNodeCompromise}
                onRestoreAllSafe={handleRestoreAllSafe}
              />
              <BehaviorTimeline events={events} />
            </div>
          </div>
        )}

        {/* TAB 2: BEHAVIOR & ML ENGINE */}
        {currentTab === "anomaly" && (
          <AnomalyEngine
            vector={vector}
            breakdown={breakdown}
            onVectorChange={handleVectorChange}
            onTriggerExplainableAlert={handleTriggerExplainableAlert}
            isAnalyzing={isAnalyzingAlert}
          />
        )}

        {/* TAB 3: AI PHISHING DETECTOR */}
        {currentTab === "phishing" && (
          <PhishingScanner
            onScan={handleScanPhishing}
            analysisResult={phishingResult}
            isScanning={isScanningPhishing}
          />
        )}

        {/* TAB 4: DIGITAL TWIN EXPOSURE GRAPH */}
        {currentTab === "digital-twin" && (
          <div className="space-y-6">
            <DigitalTwinGraph
              nodes={nodes}
              edges={edges}
              onSimulateCompromise={handleSimulateNodeCompromise}
              onRestoreAllSafe={handleRestoreAllSafe}
            />
          </div>
        )}

        {/* TAB 5: SHADOW SIMULATION */}
        {currentTab === "shadow-sim" && <ShadowSimulator />}

        {/* TAB 6: AI SECURITY COACH */}
        {currentTab === "coach" && <SecurityCoach profile={profile} />}

        {/* TAB 7: GAMIFICATION & MISSIONS */}
        {currentTab === "gamification" && (
          <GamificationView
            missions={missions}
            onToggleMission={handleToggleMission}
            onMissionCompletedReward={(xp) => {}}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-900 py-6 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center space-x-2">
            <span className="font-mono font-bold text-slate-300">CyberShadow</span>
            <span>— Personal Cyber Risk Score &amp; Behavioral Anomaly Defense System</span>
          </div>
          <div className="flex items-center space-x-3 text-slate-400">
            <span>Local-First Zero-Knowledge</span>
            <span>•</span>
            <span>CISA Phishing-Resistant MFA Standard</span>
            <span>•</span>
            <span>Isolation Forest &amp; Circadian Modeling</span>
          </div>
        </div>
      </footer>

      {/* Modals */}
      <HackathonDemoModal
        isOpen={isDemoModalOpen}
        onClose={() => setIsDemoModalOpen(false)}
        onExecuteDemoStep={handleExecuteDemoStep}
      />

      <PrivacyModal
        isOpen={isPrivacyModalOpen}
        onClose={() => setIsPrivacyModalOpen(false)}
        profile={profile}
        onTogglePrivacyMode={() =>
          setProfile((p) => ({ ...p, privacyMode: !p.privacyMode }))
        }
        onDeleteProfile={handleResetToBaseline}
      />
    </div>
  );
}
