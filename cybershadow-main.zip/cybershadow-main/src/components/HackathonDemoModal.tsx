import React, { useState } from "react";
import {
  PlayCircle,
  CheckCircle2,
  ChevronRight,
  ChevronLeft,
  X,
  Sparkles,
  ShieldAlert,
  ShieldCheck,
  RotateCcw,
  Zap,
} from "lucide-react";

interface HackathonDemoModalProps {
  isOpen: boolean;
  onClose: () => void;
  onExecuteDemoStep: (stepNumber: number) => void;
}

export const HackathonDemoModal: React.FC<HackathonDemoModalProps> = ({
  isOpen,
  onClose,
  onExecuteDemoStep,
}) => {
  const [currentStep, setCurrentStep] = useState<number>(1);

  const steps = [
    {
      step: 1,
      title: "1. Baseline User Profile Loaded",
      description:
        "Open dashboard with normal user profile (Rohan Sharma, CS Undergrad). Baseline hours: 09:00 - 23:00, Normal location: Hyderabad, Known devices: MacBook Air & Pixel 8.",
      actionLabel: "Load Normal Baseline",
      impact: "Risk Score: 12/100 (LOW) — Secure & Healthy",
    },
    {
      step: 2,
      title: "2. Circadian Telemetry Validation",
      description:
        "Observe normal evening login at 19:30 on Airtel broadband. The behavioral engine records distance = 0 km and failed attempts = 0.",
      actionLabel: "Verify Normal Telemetry",
      impact: "Formula components L=0, D=0, F=0, T=0, B=0.",
    },
    {
      step: 3,
      title: "3. Foreign Device Anomaly Injected",
      description:
        "Simulate an unauthorized login from an unknown Windows device in Bucharest, Romania (5,800 km away) at 03:00 AM outside typical active hours.",
      actionLabel: "Trigger Bucharest 3 AM Login",
      impact: "High risk behavioral deviation detected!",
    },
    {
      step: 4,
      title: "4. Rapid Password Change & Score Surge",
      description:
        "Followed immediately by 5 failed login attempts and an unauthorized credential change request. The quantitative risk formula spikes.",
      actionLabel: "Inject Credential Tampering",
      impact: "Risk Score surges from 12 → 87/100 (CRITICAL)",
    },
    {
      step: 5,
      title: "5. Upload Malicious Phishing Lure",
      description:
        "User receives an email: 'URGENT: Your college account will be disabled today. Click here immediately to verify your password: http://college-login-security.example'.",
      actionLabel: "Scan Phishing Sample",
      impact: "Forward message to CyberShadow AI Scanner",
    },
    {
      step: 6,
      title: "6. AI Phishing & Spoofing Decomposition",
      description:
        "Gemini 3.8 Flash dissects urgent coercive tone, detects typosquatted '.example' domain, and highlights credential harvesting intent.",
      actionLabel: "View AI Decomposition",
      impact: "Flagged: Critical Threat, 4 indicators identified",
    },
    {
      step: 7,
      title: "7. Explainable Natural Language Alert",
      description:
        "CyberShadow explains WHY it is dangerous in plain English: 'This login occurred from a new device, at 3:00 AM, and 5,800 km away, followed by 5 failed attempts.'",
      actionLabel: "Display Explainable Alert",
      impact: "User instantly understands the exact context",
    },
    {
      step: 8,
      title: "8. Digital Twin Lateral Exposure Graph",
      description:
        "The Cybersecurity Digital Twin visually highlights blast radius: Foreign Device → University Gmail → Cloud Storage → Campus SSH Keys.",
      actionLabel: "Inspect Digital Twin Blast Radius",
      impact: "Lateral pivoting pathways illuminated in red",
    },
    {
      step: 9,
      title: "9. Execute Advisory Defense Actions",
      description:
        "Apply recommended incident steps: Invalidate foreign session, rotate password, and enforce CISA-recommended phishing-resistant FIDO2 passkeys.",
      actionLabel: "Apply Recommended Defense",
      impact: "Simulated revocation and hardware MFA binding",
    },
    {
      step: 10,
      title: "10. Post-Mitigation Score Recovery",
      description:
        "With foreign session terminated and FIDO2 passkeys enforced, lateral pivot pathways are severed and the risk score drops back to safe baseline.",
      actionLabel: "Complete Hackathon Demo",
      impact: "Risk Score restored to 8/100 (SAFE) — Protected!",
    },
  ];

  if (!isOpen) return null;

  const currentStepData = steps[currentStep - 1];

  const handleStepClick = (stepNum: number) => {
    setCurrentStep(stepNum);
    onExecuteDemoStep(stepNum);
  };

  const handleNext = () => {
    if (currentStep < steps.length) {
      const nextStep = currentStep + 1;
      setCurrentStep(nextStep);
      onExecuteDemoStep(nextStep);
    }
  };

  const handlePrev = () => {
    if (currentStep > 1) {
      const prevStep = currentStep - 1;
      setCurrentStep(prevStep);
      onExecuteDemoStep(prevStep);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-2xl w-full p-6 shadow-2xl relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center space-x-3 mb-5">
          <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center">
            <PlayCircle className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h3 className="text-base font-bold text-white font-mono">
                3-Minute Hackathon Demonstration
              </h3>
              <span className="text-[10px] bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded-full font-bold uppercase">
                Step {currentStep} of 10
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Follows the official 10-step hackathon presentation roadmap
            </p>
          </div>
        </div>

        {/* Step pill strip */}
        <div className="flex overflow-x-auto gap-1 pb-2 mb-4 scrollbar-none">
          {steps.map((s) => (
            <button
              key={s.step}
              onClick={() => handleStepClick(s.step)}
              className={`w-7 h-7 shrink-0 rounded-lg text-xs font-bold font-mono transition-all cursor-pointer ${
                s.step === currentStep
                  ? "bg-amber-500 text-slate-950 shadow-md"
                  : s.step < currentStep
                  ? "bg-teal-500/20 text-teal-300 border border-teal-500/40"
                  : "bg-slate-800 text-slate-400 hover:bg-slate-700"
              }`}
            >
              {s.step}
            </button>
          ))}
        </div>

        {/* Active Step Card */}
        <div className="bg-slate-950/80 rounded-2xl p-5 border border-slate-800/80 mb-5">
          <h4 className="text-sm font-bold text-slate-100 flex items-center space-x-2">
            <span>{currentStepData.title}</span>
          </h4>
          <p className="text-xs text-slate-300 mt-2 leading-relaxed">
            {currentStepData.description}
          </p>

          <div className="mt-3 p-2.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between text-xs">
            <span className="text-slate-400 font-mono">Live Impact:</span>
            <span className="font-bold text-amber-300 font-mono">
              {currentStepData.impact}
            </span>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center justify-between">
          <button
            onClick={handlePrev}
            disabled={currentStep === 1}
            className="flex items-center space-x-1 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold disabled:opacity-30 cursor-pointer"
          >
            <ChevronLeft className="w-4 h-4" />
            <span>Previous</span>
          </button>

          <button
            onClick={() => handleStepClick(currentStep)}
            className="px-4 py-2 rounded-xl bg-teal-600 hover:bg-teal-500 text-white text-xs font-bold flex items-center space-x-2 shadow-md shadow-teal-500/20 cursor-pointer"
          >
            <Zap className="w-4 h-4" />
            <span>Execute: {currentStepData.actionLabel}</span>
          </button>

          {currentStep < 10 ? (
            <button
              onClick={handleNext}
              className="flex items-center space-x-1 px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold cursor-pointer"
            >
              <span>Next</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          ) : (
            <button
              onClick={onClose}
              className="px-4 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold cursor-pointer"
            >
              Finish Demo
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
