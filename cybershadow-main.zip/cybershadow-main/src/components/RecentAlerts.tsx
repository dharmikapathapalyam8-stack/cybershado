import React from "react";
import {
  AlertCircle,
  AlertTriangle,
  ShieldCheck,
  CheckCircle2,
  Clock,
  ExternalLink,
  Zap,
  Info,
  ChevronRight,
  ShieldAlert,
} from "lucide-react";
import { ExplainableAlert, RiskLevel } from "../types";

interface RecentAlertsProps {
  alerts: ExplainableAlert[];
  onApplyAction: (alertId: string, actionIndex: number) => void;
  onDismissAlert: (alertId: string) => void;
}

export const RecentAlerts: React.FC<RecentAlertsProps> = ({
  alerts,
  onApplyAction,
  onDismissAlert,
}) => {
  if (alerts.length === 0) {
    return (
      <div className="bg-slate-900/80 rounded-2xl border border-slate-800 p-6 text-center">
        <div className="w-12 h-12 rounded-full bg-emerald-500/10 text-emerald-400 flex items-center justify-center mx-auto mb-3">
          <ShieldCheck className="w-6 h-6" />
        </div>
        <h3 className="text-base font-semibold text-slate-200">All Clear — No Active Threat Alerts</h3>
        <p className="text-xs text-slate-400 mt-1 max-w-md mx-auto">
          Current activity matches your normal baseline in Hyderabad across known devices and typical hours.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <ShieldAlert className="w-5 h-5 text-amber-400" />
          <h2 className="text-base font-bold text-white tracking-tight">
            Explainable AI Security Alerts ({alerts.length})
          </h2>
        </div>
        <span className="text-xs text-slate-400">
          Reasoning derived from personal behavioral deviation
        </span>
      </div>

      <div className="space-y-3">
        {alerts.map((alert) => {
          let badgeColor = "bg-amber-500/10 text-amber-400 border-amber-500/30";
          if (alert.riskLevel === "Critical") {
            badgeColor = "bg-rose-500/10 text-rose-400 border-rose-500/30";
          } else if (alert.riskLevel === "High") {
            badgeColor = "bg-orange-500/10 text-orange-400 border-orange-500/30";
          }

          return (
            <div
              key={alert.id}
              className="bg-slate-900/90 rounded-2xl border border-slate-800 p-5 shadow-lg relative overflow-hidden"
            >
              {/* Highlight ribbon */}
              <div
                className={`absolute top-0 left-0 bottom-0 w-1.5 ${
                  alert.riskLevel === "Critical"
                    ? "bg-rose-500"
                    : alert.riskLevel === "High"
                    ? "bg-orange-500"
                    : "bg-amber-500"
                }`}
              />

              <div className="pl-2">
                {/* Header info */}
                <div className="flex flex-wrap items-center justify-between gap-2 mb-2.5">
                  <div className="flex items-center space-x-2">
                    <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold border ${badgeColor}`}>
                      {alert.riskLevel.toUpperCase()} RISK: {alert.riskScore}/100
                    </span>
                    <span className="text-xs text-slate-400 flex items-center space-x-1">
                      <Clock className="w-3.5 h-3.5" />
                      <span>{alert.timestamp}</span>
                    </span>
                  </div>

                  <span className="text-xs font-mono text-teal-400 bg-teal-500/10 px-2 py-0.5 rounded border border-teal-500/20">
                    Vector: {alert.threatVector}
                  </span>
                </div>

                <h3 className="text-base font-bold text-slate-100">{alert.title}</h3>

                {/* Plain-language explanation */}
                <p className="text-sm text-slate-300 mt-1.5 leading-relaxed bg-slate-950/60 p-3 rounded-xl border border-slate-800/80">
                  {alert.explanationText}
                </p>

                {/* Breakdown of specific reasons */}
                <div className="mt-3">
                  <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-1.5">
                    Why CyberShadow flagged this:
                  </span>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {alert.reasons.map((reason, idx) => (
                      <div
                        key={idx}
                        className="flex items-start space-x-2 text-xs text-slate-300 bg-slate-800/50 p-2 rounded-lg border border-slate-700/50"
                      >
                        <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                        <span>{reason}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Prioritized Recommended Actions */}
                <div className="mt-4 pt-3 border-t border-slate-800">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-semibold text-teal-300 uppercase tracking-wider flex items-center space-x-1.5">
                      <Zap className="w-3.5 h-3.5 text-teal-400" />
                      <span>Recommended Advisory Actions (Prioritized)</span>
                    </span>
                    <span className="text-[11px] text-slate-400">
                      Advisory defense — does not alter system without user consent
                    </span>
                  </div>

                  <div className="space-y-2">
                    {alert.actions.map((act, aIdx) => (
                      <div
                        key={aIdx}
                        className={`flex flex-col sm:flex-row sm:items-center justify-between p-2.5 rounded-xl border transition-all ${
                          act.applied
                            ? "bg-emerald-950/30 border-emerald-500/40 text-emerald-300"
                            : "bg-slate-950/80 border-slate-800 hover:border-slate-700"
                        }`}
                      >
                        <div className="flex items-start space-x-2.5 mb-2 sm:mb-0">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase shrink-0 mt-0.5 ${
                              act.priority === "Urgent"
                                ? "bg-rose-500/20 text-rose-300 border border-rose-500/30"
                                : act.priority === "High"
                                ? "bg-orange-500/20 text-orange-300 border border-orange-500/30"
                                : "bg-sky-500/20 text-sky-300 border border-sky-500/30"
                            }`}
                          >
                            {act.priority}
                          </span>
                          <div>
                            <div className="text-xs font-semibold text-slate-100 flex items-center space-x-1">
                              <span>{act.title}</span>
                              {act.title.toLowerCase().includes("mfa") && (
                                <span className="text-[10px] bg-teal-500/20 text-teal-300 px-1.5 rounded font-normal">
                                  CISA Standard
                                </span>
                              )}
                            </div>
                            <p className="text-[11px] text-slate-400">{act.description}</p>
                          </div>
                        </div>

                        <div className="shrink-0 flex items-center space-x-2">
                          {act.applied ? (
                            <span className="flex items-center space-x-1 text-xs font-semibold text-emerald-400 px-3 py-1 bg-emerald-500/10 rounded-lg">
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              <span>Protected</span>
                            </span>
                          ) : (
                            <button
                              onClick={() => onApplyAction(alert.id, aIdx)}
                              className="px-3 py-1 rounded-lg bg-teal-600 hover:bg-teal-500 text-white text-xs font-semibold shadow-sm transition-colors cursor-pointer"
                            >
                              Execute Action
                            </button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
