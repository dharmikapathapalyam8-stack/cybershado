import React from "react";
import {
  ShieldAlert,
  ShieldCheck,
  EyeOff,
  Sparkles,
  PlayCircle,
  RotateCcw,
  Activity,
  Layers,
  Search,
  BookOpen,
  Trophy,
  UserCheck,
} from "lucide-react";
import { UserCyberProfile } from "../types";

interface HeaderProps {
  profile: UserCyberProfile;
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  onOpenDemo: () => void;
  onResetToBaseline: () => void;
  onTogglePrivacy: () => void;
  onOpenPrivacyModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  profile,
  currentTab,
  setCurrentTab,
  onOpenDemo,
  onResetToBaseline,
  onTogglePrivacy,
  onOpenPrivacyModal,
}) => {
  const tabs = [
    { id: "dashboard", label: "Dashboard", icon: Activity },
    { id: "anomaly", label: "Behavior & ML Engine", icon: Layers },
    { id: "phishing", label: "AI Phishing Detector", icon: Search },
    { id: "digital-twin", label: "Digital Twin Graph", icon: EyeOff },
    { id: "shadow-sim", label: "Shadow Simulation", icon: Sparkles },
    { id: "coach", label: "AI Security Coach", icon: BookOpen },
    { id: "gamification", label: "Missions & Quiz", icon: Trophy },
  ];

  return (
    <header className="sticky top-0 z-40 bg-slate-900/95 backdrop-blur-md border-b border-slate-800 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Identity */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 via-teal-600 to-indigo-700 flex items-center justify-center shadow-lg shadow-teal-500/20">
              <ShieldCheck className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-xl font-bold tracking-tight text-white font-mono">
                  Cyber<span className="text-teal-400">Shadow</span>
                </span>
                <span className="text-[10px] uppercase font-semibold px-2 py-0.5 rounded-full bg-teal-500/10 text-teal-300 border border-teal-500/20">
                  Behavioral Defense
                </span>
              </div>
              <p className="text-xs text-slate-400 hidden sm:block">
                Personal Cyber Risk Score &amp; Explainable Anomaly Shield
              </p>
            </div>
          </div>

          {/* Action Center & Privacy Badge */}
          <div className="flex items-center space-x-2 sm:space-x-3">
            {/* Hackathon 3-min Demo Button */}
            <button
              onClick={onOpenDemo}
              className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 text-xs font-bold shadow-md shadow-amber-500/20 transition-all cursor-pointer"
              title="Launch guided 3-minute hackathon demonstration"
            >
              <PlayCircle className="w-4 h-4 text-slate-950" />
              <span className="hidden md:inline">3-Min Hackathon Demo</span>
              <span className="md:hidden">Demo</span>
            </button>

            {/* Privacy Mode Badge */}
            <button
              onClick={onOpenPrivacyModal}
              className={`flex items-center space-x-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium border transition-colors cursor-pointer ${
                profile.privacyMode
                  ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-300 hover:bg-emerald-500/20"
                  : "bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700"
              }`}
              title="View Local-First Privacy Mode guarantee"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span className="hidden lg:inline">Local-First Privacy:</span>
              <span className="font-semibold text-emerald-400">Active</span>
            </button>

            {/* Reset to Baseline Button */}
            <button
              onClick={onResetToBaseline}
              className="p-1.5 rounded-lg bg-slate-800 border border-slate-700 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
              title="Reset state to normal baseline user profile"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex overflow-x-auto space-x-1 pb-2 pt-1 border-t border-slate-800/80 scrollbar-none">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = currentTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setCurrentTab(tab.id)}
                className={`flex items-center space-x-2 px-3 py-1.5 rounded-md text-xs font-medium whitespace-nowrap transition-all cursor-pointer ${
                  isActive
                    ? "bg-teal-500/20 text-teal-300 border border-teal-500/30 shadow-sm"
                    : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/60"
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? "text-teal-400" : "text-slate-400"}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
};
