import React, { useState } from "react";
import {
  Sparkles,
  ShieldAlert,
  ShieldCheck,
  Smartphone,
  Link,
  Lock,
  AlertTriangle,
  Layers,
  CheckCircle2,
  FileCheck,
} from "lucide-react";

interface ShadowSimulationData {
  threatLevel: string;
  riskScore: number;
  verdict: string;
  exposedAssets: string[];
  blastRadiusAnalysis: string;
  recommendedPrecautions: string[];
}

export const ShadowSimulator: React.FC = () => {
  const [targetType, setTargetType] = useState<"app" | "url">("app");
  const [appName, setAppName] = useState("FastPDF Student Scanner & Downloader");
  const [targetUrl, setTargetUrl] = useState("http://student-exam-verify.xyz/auth");
  const [selectedPermissions, setSelectedPermissions] = useState<string[]>([
    "Accessibility Service (Can inspect all screens)",
    "Read SMS & Notification Listeners (Can intercept OTPs)",
    "Storage & All Files Access",
  ]);
  const [result, setResult] = useState<ShadowSimulationData | null>(null);
  const [loading, setLoading] = useState(false);

  const availablePermissions = [
    "Accessibility Service (Can inspect all screens)",
    "Read SMS & Notification Listeners (Can intercept OTPs)",
    "Storage & All Files Access",
    "Record Audio in Background",
    "Coarse / Precise Location",
    "Contacts & Address Book",
    "Draw Over Other Apps (Overlay Attack)",
    "Network / Internet Only",
  ];

  const togglePermission = (perm: string) => {
    setSelectedPermissions((prev) =>
      prev.includes(perm) ? prev.filter((p) => p !== perm) : [...prev, perm]
    );
  };

  const handleSimulate = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/gemini/simulate-shadow", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          targetName: targetType === "app" ? appName : "Target URL",
          targetType,
          requestedPermissions: targetType === "app" ? selectedPermissions : [],
          url: targetType === "url" ? targetUrl : "",
        }),
      });
      const data = await res.json();
      if (data.success && data.data) {
        setResult(data.data);
      }
    } catch (err) {
      console.error("Shadow simulation error:", err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-5 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center space-x-2">
              <Sparkles className="w-5 h-5 text-teal-400" />
              <h2 className="text-base font-bold text-white tracking-tight">
                Shadow Simulation (Pre-Installation &amp; Pre-Click Sandbox)
              </h2>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Simulate hypothetical exposure before granting permissions or opening unverified links.
            </p>
          </div>
          <div className="flex bg-slate-950/70 p-1 rounded-lg border border-slate-800">
            <button
              onClick={() => setTargetType("app")}
              className={`px-3 py-1 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                targetType === "app" ? "bg-teal-500 text-slate-950" : "text-slate-400 hover:text-slate-200"
              }`}
            >
              App Permissions
            </button>
            <button
              onClick={() => setTargetType("url")}
              className={`px-3 py-1 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                targetType === "url" ? "bg-teal-500 text-slate-950" : "text-slate-400 hover:text-slate-200"
              }`}
            >
              Link &amp; Domain
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left: Configuration */}
        <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-5 shadow-xl space-y-4">
          {targetType === "app" ? (
            <>
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Candidate Application / APK Name
                </label>
                <input
                  type="text"
                  value={appName}
                  onChange={(e) => setAppName(e.target.value)}
                  className="w-full bg-slate-950/80 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-teal-500 font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-2">
                  Permissions Requested by App:
                </label>
                <div className="space-y-2">
                  {availablePermissions.map((perm) => {
                    const isChecked = selectedPermissions.includes(perm);
                    const isDangerous =
                      perm.includes("Accessibility") ||
                      perm.includes("SMS") ||
                      perm.includes("All Files") ||
                      perm.includes("Overlay");

                    return (
                      <div
                        key={perm}
                        onClick={() => togglePermission(perm)}
                        className={`p-2 rounded-xl border text-xs flex items-center justify-between cursor-pointer transition-colors ${
                          isChecked
                            ? isDangerous
                              ? "bg-rose-950/30 border-rose-500/40 text-rose-200"
                              : "bg-teal-950/30 border-teal-500/40 text-teal-200"
                            : "bg-slate-950/50 border-slate-800 text-slate-400 hover:border-slate-700"
                        }`}
                      >
                        <span className="flex items-center space-x-2">
                          <input
                            type="checkbox"
                            checked={isChecked}
                            onChange={() => {}}
                            className="rounded border-slate-700"
                          />
                          <span>{perm}</span>
                        </span>
                        {isDangerous && (
                          <span className="text-[9px] font-bold uppercase bg-rose-500/20 text-rose-300 px-1.5 py-0.5 rounded">
                            Dangerous
                          </span>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            </>
          ) : (
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Candidate Destination URL
              </label>
              <input
                type="text"
                value={targetUrl}
                onChange={(e) => setTargetUrl(e.target.value)}
                className="w-full bg-slate-950/80 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-teal-500 font-mono"
              />
              <p className="text-[11px] text-slate-400 mt-1">
                CyberShadow simulates whether domain certificate, typosquatting characters, and OAuth redirects pose risk.
              </p>
            </div>
          )}

          <button
            onClick={handleSimulate}
            disabled={loading}
            className="w-full py-2.5 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-bold text-xs flex items-center justify-center space-x-2 shadow-lg shadow-teal-500/20 transition-all cursor-pointer disabled:opacity-50"
          >
            {loading ? (
              <span>Simulating Hypothetical Exposure...</span>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>Run Shadow Simulation</span>
              </>
            )}
          </button>
        </div>

        {/* Right: Simulation Output */}
        <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-5 shadow-xl flex flex-col justify-between">
          {result ? (
            <div className="space-y-4">
              <div
                className={`p-4 rounded-xl border ${
                  result.threatLevel === "Hazardous"
                    ? "bg-rose-950/30 border-rose-500/40 text-rose-300"
                    : "bg-amber-950/30 border-amber-500/40 text-amber-300"
                }`}
              >
                <span className="text-[10px] font-bold uppercase tracking-wider block">
                  Simulated Threat Verdict
                </span>
                <h3 className="text-base font-bold font-mono">
                  {result.threatLevel.toUpperCase()} (Simulated Risk: {result.riskScore}/100)
                </h3>
                <p className="text-xs text-slate-200 mt-1">{result.verdict}</p>
              </div>

              <div>
                <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-1.5">
                  Exposed Accounts &amp; Assets:
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {result.exposedAssets.map((asset, i) => (
                    <span
                      key={i}
                      className="px-2 py-1 bg-slate-950 text-slate-200 rounded-lg border border-slate-800 text-xs font-mono"
                    >
                      {asset}
                    </span>
                  ))}
                </div>
              </div>

              <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-800">
                <span className="text-xs font-semibold text-teal-300 uppercase tracking-wider block mb-1">
                  Potential Damage Blast Radius:
                </span>
                <p className="text-xs text-slate-300 leading-relaxed">
                  {result.blastRadiusAnalysis}
                </p>
              </div>

              <div>
                <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-1.5">
                  Preventative Security Controls:
                </span>
                <ul className="space-y-1.5 text-xs text-slate-300">
                  {result.recommendedPrecautions.map((ctrl, i) => (
                    <li key={i} className="flex items-start space-x-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-teal-400 shrink-0 mt-0.5" />
                      <span>{ctrl}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-500">
              <Sparkles className="w-12 h-12 mb-3 stroke-1 text-slate-600" />
              <p className="text-sm text-slate-400 font-medium">No Active Simulation</p>
              <p className="text-xs text-slate-500 mt-1 max-w-xs">
                Configure permissions or URL and run the sandbox to view prospective damage radius.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
