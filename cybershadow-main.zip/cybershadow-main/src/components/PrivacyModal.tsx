import React from "react";
import {
  ShieldCheck,
  Lock,
  EyeOff,
  Trash2,
  CheckCircle2,
  XCircle,
  X,
  AlertCircle,
  FileText,
} from "lucide-react";
import { UserCyberProfile } from "../types";

interface PrivacyModalProps {
  isOpen: boolean;
  onClose: () => void;
  profile: UserCyberProfile;
  onTogglePrivacyMode: () => void;
  onDeleteProfile: () => void;
}

export const PrivacyModal: React.FC<PrivacyModalProps> = ({
  isOpen,
  onClose,
  profile,
  onTogglePrivacyMode,
  onDeleteProfile,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-lg w-full p-6 shadow-2xl relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center space-x-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center justify-center">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white">Local-First Privacy Architecture</h3>
            <p className="text-xs text-slate-400">Zero-knowledge indicators over raw content</p>
          </div>
        </div>

        <p className="text-xs text-slate-300 leading-relaxed mb-4">
          CyberShadow is engineered specifically for students, families, and privacy-sensitive users. Unlike legacy telemetry agents, CyberShadow extracts mathematical features and discards raw message content.
        </p>

        {/* Comparison Table */}
        <div className="grid grid-cols-2 gap-3 mb-5 text-xs">
          <div className="bg-emerald-950/20 border border-emerald-500/30 rounded-xl p-3">
            <div className="flex items-center space-x-1.5 font-bold text-emerald-400 mb-2">
              <CheckCircle2 className="w-4 h-4" />
              <span>What We Store:</span>
            </div>
            <ul className="space-y-1 text-[11px] text-slate-300">
              <li>• Anonymized login hour &amp; coarse location</li>
              <li>• Cryptographic device familiarity hash</li>
              <li>• Outbound MB count &amp; failed attempt tally</li>
              <li>• Threat flags (e.g. "Lookalike Domain")</li>
            </ul>
          </div>

          <div className="bg-rose-950/20 border border-rose-500/30 rounded-xl p-3">
            <div className="flex items-center space-x-1.5 font-bold text-rose-400 mb-2">
              <XCircle className="w-4 h-4" />
              <span>What is NEVER Stored:</span>
            </div>
            <ul className="space-y-1 text-[11px] text-slate-300">
              <li>• Raw email or chat content</li>
              <li>• Passwords, PINs, or OTP tokens</li>
              <li>• Private file contents</li>
              <li>• Unanonymized keystroke logs</li>
            </ul>
          </div>
        </div>

        {/* Profile Settings */}
        <div className="space-y-3 pt-3 border-t border-slate-800">
          <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950/70 border border-slate-800">
            <div>
              <span className="text-xs font-semibold text-white block">
                Local-First Processing
              </span>
              <span className="text-[11px] text-slate-400">
                Process feature extraction in local browser storage
              </span>
            </div>
            <button
              onClick={onTogglePrivacyMode}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                profile.privacyMode
                  ? "bg-emerald-500 text-slate-950"
                  : "bg-slate-800 text-slate-400"
              }`}
            >
              {profile.privacyMode ? "Enabled" : "Disabled"}
            </button>
          </div>

          <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950/70 border border-slate-800">
            <div>
              <span className="text-xs font-semibold text-rose-300 block">
                Delete Cyber Shadow Profile
              </span>
              <span className="text-[11px] text-slate-400">
                Purges all learned baseline models and historical telemetry
              </span>
            </div>
            <button
              onClick={() => {
                if (confirm("Are you sure you want to delete your personal cyber profile and reset all baseline history?")) {
                  onDeleteProfile();
                  onClose();
                }
              }}
              className="px-3 py-1 rounded-lg text-xs font-semibold bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/30 flex items-center space-x-1 cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Purge Profile</span>
            </button>
          </div>
        </div>

        <div className="mt-5 text-right">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold rounded-xl cursor-pointer"
          >
            Close Privacy Center
          </button>
        </div>
      </div>
    </div>
  );
};
