import React, { useState } from "react";
import {
  Trophy,
  Award,
  CheckCircle2,
  Sparkles,
  ShieldCheck,
  HelpCircle,
  Zap,
  ArrowRight,
} from "lucide-react";
import { GamificationMission } from "../types";

interface GamificationViewProps {
  missions: GamificationMission[];
  onToggleMission: (id: string) => void;
  onMissionCompletedReward: (xpEarned: number) => void;
}

export const GamificationView: React.FC<GamificationViewProps> = ({
  missions,
  onToggleMission,
  onMissionCompletedReward,
}) => {
  const [totalXp, setTotalXp] = useState<number>(420);
  const [quizAnswer, setQuizAnswer] = useState<number | null>(null);
  const [quizSubmitted, setQuizSubmitted] = useState<boolean>(false);

  const completedCount = missions.filter((m) => m.completed).length;

  const quizQuestion = {
    prompt:
      "Why is FIDO2 / WebAuthn hardware-based authentication considered 'phishing-resistant' compared to standard SMS OTPs?",
    options: [
      "Because it costs more money to purchase a hardware security key.",
      "Because the cryptographic handshake binds directly to the specific verified domain in the browser address bar, making fake lookalike sites unable to harvest credentials.",
      "Because SMS networks are encrypted with 512-bit keys.",
      "Because students only authenticate once a semester.",
    ],
    correctIndex: 1,
    explanation:
      "CISA emphasizes that FIDO2 passkeys rely on public-key cryptography tied to the exact origin domain. Even if an attacker creates a perfect replica of a login page on a lookalike domain, the browser will refuse to supply credentials!",
  };

  const handleQuizSubmit = (optIndex: number) => {
    if (quizSubmitted) return;
    setQuizAnswer(optIndex);
    setQuizSubmitted(true);
    if (optIndex === quizQuestion.correctIndex) {
      setTotalXp((prev) => prev + 50);
      onMissionCompletedReward(50);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header with XP & Level */}
      <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-5 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <Trophy className="w-5 h-5 text-amber-400" />
              <h2 className="text-base font-bold text-white tracking-tight">
                Cybersecurity Gamification &amp; Weekly Defense Missions
              </h2>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Turn security hygiene into engaging habits. Complete missions to increase resilience and lower risk.
            </p>
          </div>

          <div className="flex items-center space-x-3 bg-slate-950/80 p-2.5 rounded-xl border border-slate-800">
            <div className="text-right">
              <span className="text-[10px] uppercase font-bold text-amber-400 block font-mono">
                Guardian Tier 3
              </span>
              <span className="text-sm font-extrabold text-white font-mono">
                {totalXp} XP
              </span>
            </div>
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-300">
              <Award className="w-5 h-5" />
            </div>
          </div>
        </div>

        {/* Progress bar */}
        <div className="mt-4 pt-3 border-t border-slate-800">
          <div className="flex justify-between text-xs text-slate-300 mb-1">
            <span>Weekly Mission Progress: {completedCount} of {missions.length} completed</span>
            <span className="font-mono text-teal-400">{Math.round((completedCount / missions.length) * 100)}%</span>
          </div>
          <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
            <div
              className="bg-gradient-to-r from-teal-500 to-amber-400 h-full rounded-full transition-all duration-500"
              style={{ width: `${(completedCount / missions.length) * 100}%` }}
            />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Mission Cards */}
        <div className="lg:col-span-2 space-y-3">
          <h3 className="text-xs font-bold text-teal-300 uppercase tracking-wider flex items-center space-x-1.5">
            <Zap className="w-3.5 h-3.5" />
            <span>Active Weekly Defensive Missions</span>
          </h3>

          <div className="space-y-2.5">
            {missions.map((mission) => (
              <div
                key={mission.id}
                className={`p-4 rounded-xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                  mission.completed
                    ? "bg-emerald-950/20 border-emerald-500/30"
                    : "bg-slate-900/90 border-slate-800 hover:border-slate-700"
                }`}
              >
                <div className="flex items-start space-x-3">
                  <div
                    onClick={() => onToggleMission(mission.id)}
                    className={`w-5 h-5 rounded-md flex items-center justify-center cursor-pointer mt-0.5 border ${
                      mission.completed
                        ? "bg-emerald-500 border-emerald-400 text-slate-950"
                        : "border-slate-700 bg-slate-800 hover:border-teal-500"
                    }`}
                  >
                    {mission.completed && <CheckCircle2 className="w-3.5 h-3.5" />}
                  </div>

                  <div>
                    <div className="flex items-center space-x-2">
                      <h4
                        className={`text-xs font-bold ${
                          mission.completed ? "text-emerald-200 line-through" : "text-white"
                        }`}
                      >
                        {mission.title}
                      </h4>
                      <span className="text-[10px] font-mono bg-amber-500/10 text-amber-300 px-1.5 py-0.2 rounded border border-amber-500/20">
                        +{mission.xp} XP
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-0.5">{mission.description}</p>
                  </div>
                </div>

                <div className="shrink-0">
                  <button
                    onClick={() => onToggleMission(mission.id)}
                    className={`px-3 py-1 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                      mission.completed
                        ? "bg-slate-800 text-slate-400"
                        : "bg-teal-600 hover:bg-teal-500 text-white shadow-sm"
                    }`}
                  >
                    {mission.completed ? "Completed" : mission.actionText}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right Col: Cyber Awareness Quiz */}
        <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-5 shadow-xl flex flex-col justify-between">
          <div>
            <div className="flex items-center space-x-2 text-xs font-bold text-amber-300 uppercase tracking-wider mb-2">
              <HelpCircle className="w-4 h-4 text-amber-400" />
              <span>Weekly Awareness Challenge</span>
            </div>
            <span className="text-[10px] bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded font-mono font-bold">
              Reward: +50 XP
            </span>

            <p className="text-xs font-medium text-slate-200 mt-3 mb-3 leading-relaxed">
              {quizQuestion.prompt}
            </p>

            <div className="space-y-2">
              {quizQuestion.options.map((opt, oIdx) => {
                const isSelected = quizAnswer === oIdx;
                const isCorrect = oIdx === quizQuestion.correctIndex;

                let optClass = "bg-slate-950/70 border-slate-800 hover:border-slate-700 text-slate-300";
                if (quizSubmitted) {
                  if (isCorrect) optClass = "bg-emerald-950/40 border-emerald-500 text-emerald-200 font-bold";
                  else if (isSelected) optClass = "bg-rose-950/40 border-rose-500 text-rose-200";
                }

                return (
                  <button
                    key={oIdx}
                    disabled={quizSubmitted}
                    onClick={() => handleQuizSubmit(oIdx)}
                    className={`w-full p-2.5 rounded-xl border text-left text-[11px] leading-snug transition-all cursor-pointer ${optClass}`}
                  >
                    {opt}
                  </button>
                );
              })}
            </div>
          </div>

          {quizSubmitted && (
            <div className="mt-4 p-3 rounded-xl bg-slate-950/80 border border-slate-800 text-xs">
              <span
                className={`font-bold block mb-1 ${
                  quizAnswer === quizQuestion.correctIndex ? "text-emerald-400" : "text-rose-400"
                }`}
              >
                {quizAnswer === quizQuestion.correctIndex
                  ? "✓ Correct Answer! (+50 XP)"
                  : "✗ Not Quite — Here is why:"}
              </span>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                {quizQuestion.explanation}
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
