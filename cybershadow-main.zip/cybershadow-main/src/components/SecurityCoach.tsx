import React, { useState } from "react";
import {
  BookOpen,
  Send,
  Sparkles,
  ShieldCheck,
  Zap,
  HelpCircle,
  Lightbulb,
  CheckCircle2,
  Lock,
} from "lucide-react";
import { UserCyberProfile } from "../types";

interface SecurityCoachProps {
  profile: UserCyberProfile;
}

export const SecurityCoach: React.FC<SecurityCoachProps> = ({ profile }) => {
  const [messages, setMessages] = useState<
    Array<{ sender: "user" | "coach"; text: string; time: string }>
  >([
    {
      sender: "coach",
      text: `Hello ${profile.userName}! I'm your CyberShadow AI Security Coach.
I continuously monitor your behavioral posture and guide you toward defense-in-depth:
• Your current profile risk score is ${profile.overallRiskScore}/100.
• You have MFA enabled on your University account, but your banking portal still relies on SMS OTP (which can be phished).
• 1 credential appears reused across secondary student platforms.

How can I help you strengthen your digital perimeter today?`,
      time: "Just now",
    },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);

  const predefinedPrompts = [
    "Why does CISA recommend phishing-resistant MFA over SMS codes?",
    "How does CyberShadow detect anomalies without reading my private emails?",
    "What should I do right now if I entered my password on a suspicious site?",
    "How do I eliminate reused passwords safely using a password manager?",
  ];

  const handleSend = async (queryText?: string) => {
    const q = queryText || input;
    if (!q.trim() || loading) return;

    const userMsg = {
      sender: "user" as const,
      text: q,
      time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    setLoading(true);

    try {
      const res = await fetch("/api/gemini/coach", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          question: q,
          userProfileSummary: `${profile.userName}, ${profile.userRole}. Normal location: ${profile.normalLocations.join(", ")}. Known devices: 2. Risk Score: ${profile.overallRiskScore}/100.`,
        }),
      });
      const data = await res.json();
      const reply =
        data.advice ||
        "Always adopt phishing-resistant MFA (FIDO2 passkeys) and isolate critical college credentials from personal social accounts.";

      setMessages((prev) => [
        ...prev,
        {
          sender: "coach" as const,
          text: reply,
          time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        },
      ]);
    } catch (err) {
      console.error("Coach chat error:", err);
      setMessages((prev) => [
        ...prev,
        {
          sender: "coach" as const,
          text: "I encountered a transient network connection error. Immediate rule of thumb: If an email demands urgent verification, never click its link; open the official college portal directly in a clean browser tab.",
          time: "Just now",
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-5 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center space-x-2">
              <BookOpen className="w-5 h-5 text-teal-400" />
              <h2 className="text-base font-bold text-white tracking-tight">
                AI Security Coach &amp; Advisory Assistant
              </h2>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Personalized, plain-English cybersecurity guidance grounded in zero-trust and CISA recommendations.
            </p>
          </div>
          <span className="text-xs font-semibold text-teal-300 bg-teal-500/10 px-2.5 py-1 rounded-full border border-teal-500/20 flex items-center space-x-1">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Advisory Mode: No Unsolicited System Alteration</span>
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Chat stream */}
        <div className="lg:col-span-2 bg-slate-900/90 rounded-2xl border border-slate-800 p-4 shadow-xl flex flex-col h-[520px]">
          {/* Message scroll list */}
          <div className="flex-1 overflow-y-auto space-y-3.5 pr-2">
            {messages.map((m, idx) => (
              <div
                key={idx}
                className={`flex flex-col ${m.sender === "user" ? "items-end" : "items-start"}`}
              >
                <div
                  className={`p-3.5 rounded-2xl max-w-[85%] text-xs leading-relaxed ${
                    m.sender === "user"
                      ? "bg-teal-600 text-white rounded-br-none"
                      : "bg-slate-950/80 border border-slate-800 text-slate-200 rounded-bl-none shadow-md"
                  }`}
                >
                  <p className="whitespace-pre-line">{m.text}</p>
                </div>
                <span className="text-[10px] text-slate-500 mt-1 px-1">{m.time}</span>
              </div>
            ))}
            {loading && (
              <div className="flex items-center space-x-2 p-3 bg-slate-950/60 rounded-xl border border-slate-800 text-xs text-teal-300 w-fit">
                <span className="w-3.5 h-3.5 border-2 border-teal-400/20 border-t-teal-400 rounded-full animate-spin" />
                <span>Coach is thinking...</span>
              </div>
            )}
          </div>

          {/* Quick prompts */}
          <div className="pt-3 border-t border-slate-800 mt-2">
            <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block mb-1.5">
              Suggested Questions:
            </span>
            <div className="flex flex-wrap gap-1.5 mb-3">
              {predefinedPrompts.map((p, i) => (
                <button
                  key={i}
                  onClick={() => handleSend(p)}
                  className="px-2.5 py-1 bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 text-[11px] rounded-lg text-left transition-colors cursor-pointer"
                >
                  {p}
                </button>
              ))}
            </div>

            {/* Input bar */}
            <div className="flex items-center space-x-2">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleSend()}
                placeholder="Ask your AI Security Coach any cybersecurity question..."
                className="flex-1 bg-slate-950/90 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-teal-500"
              />
              <button
                onClick={() => handleSend()}
                disabled={loading || !input.trim()}
                className="p-2 rounded-xl bg-teal-600 hover:bg-teal-500 text-white transition-colors cursor-pointer disabled:opacity-40"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Right: Proactive Security Advisories */}
        <div className="space-y-3">
          <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-4 shadow-xl">
            <h3 className="text-xs font-bold text-teal-300 uppercase tracking-wider flex items-center space-x-1.5 mb-3">
              <Lightbulb className="w-4 h-4 text-teal-400" />
              <span>Current Profile Recommendations</span>
            </h3>

            <div className="space-y-2.5">
              <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800 text-xs">
                <span className="text-[10px] font-bold text-orange-400 uppercase block mb-1">
                  High Priority
                </span>
                <h4 className="font-bold text-slate-100 mb-0.5">
                  Upgrade Banking to Phishing-Resistant MFA
                </h4>
                <p className="text-[11px] text-slate-400">
                  Your NetBanking portal currently relies on SMS OTPs. A reverse proxy phishing attack could steal your OTP in real time.
                </p>
              </div>

              <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800 text-xs">
                <span className="text-[10px] font-bold text-amber-400 uppercase block mb-1">
                  Medium Priority
                </span>
                <h4 className="font-bold text-slate-100 mb-0.5">
                  Rotate Reused Password in Vault
                </h4>
                <p className="text-[11px] text-slate-400">
                  Password reuse detected across a campus club forum and personal storage. Credential stuffing on one could compromise both.
                </p>
              </div>

              <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800 text-xs">
                <span className="text-[10px] font-bold text-teal-400 uppercase block mb-1">
                  Good Posture
                </span>
                <h4 className="font-bold text-slate-100 mb-0.5">
                  Biometric Passkeys Enforced
                </h4>
                <p className="text-[11px] text-slate-400">
                  Your MacBook Air and Pixel 8 Pro are configured with hardware security modules (Apple Secure Enclave &amp; Titan M2).
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
