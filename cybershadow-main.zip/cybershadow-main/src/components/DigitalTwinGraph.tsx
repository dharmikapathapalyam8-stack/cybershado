import React, { useState } from "react";
import {
  Layers,
  ShieldAlert,
  ShieldCheck,
  Zap,
  Info,
  User,
  Mail,
  CreditCard,
  Code,
  Laptop,
  Smartphone,
  Server,
  Key,
  HardDrive,
  Wifi,
  ExternalLink,
} from "lucide-react";
import { DigitalTwinNode, DigitalTwinEdge } from "../types";

interface DigitalTwinGraphProps {
  nodes: DigitalTwinNode[];
  edges: DigitalTwinEdge[];
  onNodeSelect?: (node: DigitalTwinNode) => void;
  onSimulateCompromise?: (nodeId: string) => void;
  onRestoreAllSafe?: () => void;
}

export const DigitalTwinGraph: React.FC<DigitalTwinGraphProps> = ({
  nodes,
  edges,
  onNodeSelect,
  onSimulateCompromise,
  onRestoreAllSafe,
}) => {
  const [selectedNodeId, setSelectedNodeId] = useState<string>("node-untrusted-dev");

  const selectedNode = nodes.find((n) => n.id === selectedNodeId) || nodes[0];

  // Calculate blast radius (connected downstream/upstream nodes)
  const connectedEdgeIds = edges.filter(
    (e) => e.source === selectedNodeId || e.target === selectedNodeId
  );
  const affectedNodeIds = new Set<string>();
  affectedNodeIds.add(selectedNodeId);

  // 1-hop traversal for blast radius
  edges.forEach((e) => {
    if (e.source === selectedNodeId) affectedNodeIds.add(e.target);
    if (e.target === selectedNodeId) affectedNodeIds.add(e.source);
  });

  // 2-hop traversal for deeper blast radius if high risk
  edges.forEach((e) => {
    if (affectedNodeIds.has(e.source)) affectedNodeIds.add(e.target);
  });

  // Node icon resolver
  const getNodeIcon = (node: DigitalTwinNode) => {
    switch (node.id) {
      case "node-user":
        return <User className="w-5 h-5 text-indigo-400" />;
      case "node-gmail":
        return <Mail className="w-5 h-5 text-rose-400" />;
      case "node-bank":
        return <CreditCard className="w-5 h-5 text-emerald-400" />;
      case "node-github":
        return <Code className="w-5 h-5 text-slate-300" />;
      case "node-mac":
        return <Laptop className="w-5 h-5 text-sky-400" />;
      case "node-phone":
        return <Smartphone className="w-5 h-5 text-teal-400" />;
      case "node-untrusted-dev":
        return <Server className="w-5 h-5 text-rose-400 animate-pulse" />;
      case "node-drive":
        return <HardDrive className="w-5 h-5 text-amber-400" />;
      case "node-ssh":
        return <Key className="w-5 h-5 text-amber-400" />;
      case "node-passwords":
        return <Key className="w-5 h-5 text-rose-400" />;
      default:
        return <Layers className="w-5 h-5 text-teal-400" />;
    }
  };

  return (
    <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-5 shadow-xl">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 mb-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="w-2.5 h-2.5 rounded-full bg-teal-400 animate-ping" />
            <h3 className="text-base font-bold text-white tracking-tight">
              Cybersecurity Digital Twin &amp; Blast Radius
            </h3>
            <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-full bg-teal-500/10 text-teal-300 border border-teal-500/20">
              Interactive Topology
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Click any account, device, or network to calculate lateral exposure pathways.
          </p>
        </div>

        <div className="flex items-center space-x-2">
          {onSimulateCompromise && (
            <button
              onClick={() => onSimulateCompromise("node-untrusted-dev")}
              className="px-2.5 py-1.5 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/30 text-xs font-semibold transition-colors cursor-pointer"
            >
              Simulate Foreign Device Attack
            </button>
          )}
          {onRestoreAllSafe && (
            <button
              onClick={onRestoreAllSafe}
              className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold transition-colors cursor-pointer"
            >
              Restore All Nodes Safe
            </button>
          )}
        </div>
      </div>

      {/* Main Canvas & Graph Area */}
      <div className="relative w-full h-[360px] sm:h-[420px] bg-slate-950/80 rounded-xl border border-slate-800/80 overflow-hidden">
        {/* Subtle grid backdrop */}
        <div className="absolute inset-0 bg-[radial-gradient(#1e293b_1px,transparent_1px)] [background-size:16px_16px] opacity-40 pointer-events-none" />

        <svg className="w-full h-full" viewBox="0 0 800 520">
          <defs>
            <marker
              id="arrowhead-safe"
              markerWidth="8"
              markerHeight="6"
              refX="18"
              refY="3"
              orient="auto"
            >
              <polygon points="0 0, 8 3, 0 6" fill="#475569" />
            </marker>
            <marker
              id="arrowhead-risk"
              markerWidth="8"
              markerHeight="6"
              refX="18"
              refY="3"
              orient="auto"
            >
              <polygon points="0 0, 8 3, 0 6" fill="#f43f5e" />
            </marker>
            <linearGradient id="risk-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#f43f5e" />
              <stop offset="100%" stopColor="#f97316" />
            </linearGradient>
          </defs>

          {/* Render Edges */}
          {edges.map((edge) => {
            const src = nodes.find((n) => n.id === edge.source);
            const tgt = nodes.find((n) => n.id === edge.target);
            if (!src || !tgt) return null;

            const isHighlighted =
              affectedNodeIds.has(edge.source) && affectedNodeIds.has(edge.target);
            const isCompromisedPath =
              (src.status === "compromised" || tgt.status === "compromised" || edge.activeRisk) &&
              isHighlighted;

            return (
              <g key={edge.id}>
                <line
                  x1={src.x}
                  y1={src.y}
                  x2={tgt.x}
                  y2={tgt.y}
                  stroke={isCompromisedPath ? "#f43f5e" : isHighlighted ? "#06b6d4" : "#334155"}
                  strokeWidth={isCompromisedPath ? 2.5 : isHighlighted ? 2 : 1.2}
                  strokeDasharray={isCompromisedPath ? "4 4" : "none"}
                  markerEnd={isCompromisedPath ? "url(#arrowhead-risk)" : "url(#arrowhead-safe)"}
                  className={isCompromisedPath ? "animate-pulse" : ""}
                />
                {edge.label && (
                  <text
                    x={(src.x + tgt.x) / 2}
                    y={(src.y + tgt.y) / 2 - 6}
                    fill={isCompromisedPath ? "#fca5a5" : "#64748b"}
                    fontSize="9"
                    fontFamily="monospace"
                    textAnchor="middle"
                  >
                    {edge.label}
                  </text>
                )}
              </g>
            );
          })}

          {/* Render Nodes */}
          {nodes.map((node) => {
            const isSelected = selectedNodeId === node.id;
            const isAffected = affectedNodeIds.has(node.id);

            let nodeBorderColor = "#334155";
            let nodeBg = "#0f172a";

            if (node.status === "compromised") {
              nodeBorderColor = "#f43f5e";
              nodeBg = "#4c0519";
            } else if (node.status === "warning") {
              nodeBorderColor = "#f59e0b";
              nodeBg = "#451a03";
            } else if (isAffected) {
              nodeBorderColor = "#06b6d4";
              nodeBg = "#083344";
            }

            return (
              <g
                key={node.id}
                className="cursor-pointer transition-transform hover:scale-110"
                onClick={() => {
                  setSelectedNodeId(node.id);
                  if (onNodeSelect) onNodeSelect(node);
                }}
              >
                {/* Blast radius ripple if compromised or affected */}
                {isAffected && (
                  <circle
                    cx={node.x}
                    cy={node.y}
                    r={isSelected ? 32 : 26}
                    fill="none"
                    stroke={node.status === "compromised" ? "#f43f5e" : "#06b6d4"}
                    strokeWidth="1.5"
                    strokeDasharray="3 3"
                    className="animate-spin"
                    style={{ animationDuration: "12s" }}
                  />
                )}

                {/* Node Body Circle */}
                <circle
                  cx={node.x}
                  cy={node.y}
                  r={isSelected ? 22 : 18}
                  fill={nodeBg}
                  stroke={isSelected ? "#38bdf8" : nodeBorderColor}
                  strokeWidth={isSelected ? 3 : 2}
                />

                {/* Node Status Dot */}
                <circle
                  cx={node.x + 12}
                  cy={node.y - 12}
                  r={4}
                  fill={
                    node.status === "compromised"
                      ? "#f43f5e"
                      : node.status === "warning"
                      ? "#f59e0b"
                      : "#10b981"
                  }
                />

                {/* Label text */}
                <text
                  x={node.x}
                  y={node.y + 32}
                  fill={isSelected ? "#f8fafc" : "#cbd5e1"}
                  fontSize="11"
                  fontWeight={isSelected ? "bold" : "500"}
                  textAnchor="middle"
                >
                  {node.label}
                </text>
              </g>
            );
          })}
        </svg>

        {/* Legend Overlay */}
        <div className="absolute bottom-2 left-2 bg-slate-900/90 backdrop-blur p-2 rounded-lg border border-slate-800 text-[10px] space-y-1 text-slate-300">
          <div className="flex items-center space-x-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400" />
            <span>Secure Baseline</span>
          </div>
          <div className="flex items-center space-x-1.5">
            <span className="w-2 h-2 rounded-full bg-amber-400" />
            <span>Elevated Risk / Exposed</span>
          </div>
          <div className="flex items-center space-x-1.5">
            <span className="w-2 h-2 rounded-full bg-rose-500" />
            <span>Compromised / Lateral Pivot</span>
          </div>
        </div>
      </div>

      {/* Node Detail & Blast Radius Analysis Panel */}
      {selectedNode && (
        <div className="mt-3 bg-slate-950/70 rounded-xl p-3.5 border border-slate-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 shrink-0">
              {getNodeIcon(selectedNode)}
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h4 className="text-sm font-bold text-white">{selectedNode.label}</h4>
                <span
                  className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase ${
                    selectedNode.status === "compromised"
                      ? "bg-rose-500/20 text-rose-300 border border-rose-500/30"
                      : selectedNode.status === "warning"
                      ? "bg-amber-500/20 text-amber-300 border border-amber-500/30"
                      : "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30"
                  }`}
                >
                  {selectedNode.status}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">{selectedNode.details}</p>
            </div>
          </div>

          <div className="sm:text-right text-xs">
            <span className="text-slate-400 font-mono">
              Blast Radius Exposure:{" "}
              <strong className="text-amber-400">
                {affectedNodeIds.size - 1} linked services affected
              </strong>
            </span>
            <div className="text-[11px] text-slate-500 mt-0.5">
              Example pathway: Foreign Device → Gmail → Cloud Drive → SSH Keys
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
