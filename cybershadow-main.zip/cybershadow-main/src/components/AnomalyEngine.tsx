import React, { useState } from "react";
import {
  Cpu,
  Sliders,
  Play,
  RotateCcw,
  Sparkles,
  Database,
  Info,
  ShieldAlert,
  ArrowRight,
  TrendingUp,
} from "lucide-react";
import { AnomalyVector, RiskCalculationBreakdown, SyntheticDatasetRow } from "../types";
import { sampleSyntheticDataset } from "../data/cyberDefaults";

interface AnomalyEngineProps {
  vector: AnomalyVector;
  breakdown: RiskCalculationBreakdown;
  onVectorChange: (updated: Partial<AnomalyVector>) => void;
  onTriggerExplainableAlert: () => void;
  isAnalyzing?: boolean;
}

export const AnomalyEngine: React.FC<AnomalyEngineProps> = ({
  vector,
  breakdown,
  onVectorChange,
  onTriggerExplainableAlert,
  isAnalyzing,
}) => {
  const [activePreset, setActivePreset] = useState<string>("custom");

  const applyPreset = (presetKey: string) => {
    setActivePreset(presetKey);
    if (presetKey === "normal-evening") {
      onVectorChange({
        loginHour: 19,
        locationName: "Hyderabad, India (Airtel)",
        distanceKm: 0,
        locationChangeScore: 5,
        deviceName: "MacBook Air M2 (Known)",
        isNewDevice: false,
        deviceScore: 0,
        failedAttempts: 0,
        failedLoginScore: 0,
        unusualTimeScore: 5,
        dataDownloadMB: 20,
        passwordChangeAttempt: false,
        unusualFileAccess: false,
        abnormalBehaviorScore: 5,
      });
    } else if (presetKey === "foreign-night") {
      onVectorChange({
        loginHour: 3,
        locationName: "Bucharest, Romania (Tor Exit Node)",
        distanceKm: 5800,
        locationChangeScore: 95,
        deviceName: "Unknown Windows NT / TorBrowser",
        isNewDevice: true,
        deviceScore: 100,
        failedAttempts: 5,
        failedLoginScore: 80,
        unusualTimeScore: 90,
        dataDownloadMB: 850,
        passwordChangeAttempt: true,
        unusualFileAccess: true,
        abnormalBehaviorScore: 90,
      });
    } else if (presetKey === "credential-stuffing") {
      onVectorChange({
        loginHour: 2,
        locationName: "Frankfurt, Germany (DigitalOcean VPS)",
        distanceKm: 6700,
        locationChangeScore: 90,
        deviceName: "Python-Requests / Automation Client",
        isNewDevice: true,
        deviceScore: 95,
        failedAttempts: 8,
        failedLoginScore: 100,
        unusualTimeScore: 85,
        dataDownloadMB: 120,
        passwordChangeAttempt: false,
        unusualFileAccess: false,
        abnormalBehaviorScore: 70,
      });
    } else if (presetKey === "data-exfiltration") {
      onVectorChange({
        loginHour: 4,
        locationName: "Hyderabad (Campus Lab VPN)",
        distanceKm: 15,
        locationChangeScore: 20,
        deviceName: "Pixel 8 Pro (Known)",
        isNewDevice: false,
        deviceScore: 15,
        failedAttempts: 1,
        failedLoginScore: 15,
        unusualTimeScore: 80,
        dataDownloadMB: 1450,
        passwordChangeAttempt: false,
        unusualFileAccess: true,
        abnormalBehaviorScore: 95,
      });
    }
  };

  return (
    <div className="space-y-6">
      {/* Overview header */}
      <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-5 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center space-x-2">
              <Cpu className="w-5 h-5 text-teal-400" />
              <h2 className="text-base font-bold text-white tracking-tight">
                Behavioral Anomaly &amp; Data Science Scoring Engine
              </h2>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Isolation Forest &amp; Circadian modeling comparing incoming telemetry against the user’s normal pattern.
            </p>
          </div>

          <div className="flex items-center space-x-2">
            <span className="text-xs text-slate-400">Score:</span>
            <span className="text-xl font-bold font-mono text-teal-400">
              {breakdown.finalScore}/100
            </span>
            <span
              className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                breakdown.finalScore >= 76
                  ? "bg-rose-500/20 text-rose-300 border border-rose-500/30"
                  : breakdown.finalScore >= 51
                  ? "bg-orange-500/20 text-orange-300 border border-orange-500/30"
                  : breakdown.finalScore >= 26
                  ? "bg-amber-500/20 text-amber-300 border border-amber-500/30"
                  : "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30"
              }`}
            >
              {breakdown.riskLevel}
            </span>
          </div>
        </div>

        {/* Preset scenario buttons */}
        <div className="mt-4 pt-3 border-t border-slate-800">
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-2">
            Quick Simulation Presets:
          </span>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2">
            <button
              onClick={() => applyPreset("normal-evening")}
              className={`p-2 rounded-xl border text-left transition-all cursor-pointer ${
                activePreset === "normal-evening"
                  ? "bg-emerald-950/40 border-emerald-500/50 text-emerald-300"
                  : "bg-slate-950/60 border-slate-800 text-slate-300 hover:border-slate-700"
              }`}
            >
              <div className="text-xs font-bold flex items-center justify-between">
                <span>Normal Evening Study</span>
                <span className="text-[10px] text-emerald-400 font-mono">Score ~8</span>
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5">Known Mac, 19:30 PM, Hyderabad</p>
            </button>

            <button
              onClick={() => applyPreset("foreign-night")}
              className={`p-2 rounded-xl border text-left transition-all cursor-pointer ${
                activePreset === "foreign-night"
                  ? "bg-rose-950/40 border-rose-500/50 text-rose-300"
                  : "bg-slate-950/60 border-slate-800 text-slate-300 hover:border-slate-700"
              }`}
            >
              <div className="text-xs font-bold flex items-center justify-between">
                <span>Foreign Night Takeover</span>
                <span className="text-[10px] text-rose-400 font-mono">Score ~89</span>
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5">3:00 AM, Bucharest, Pass Reset</p>
            </button>

            <button
              onClick={() => applyPreset("credential-stuffing")}
              className={`p-2 rounded-xl border text-left transition-all cursor-pointer ${
                activePreset === "credential-stuffing"
                  ? "bg-orange-950/40 border-orange-500/50 text-orange-300"
                  : "bg-slate-950/60 border-slate-800 text-slate-300 hover:border-slate-700"
              }`}
            >
              <div className="text-xs font-bold flex items-center justify-between">
                <span>Credential Stuffing</span>
                <span className="text-[10px] text-orange-400 font-mono">Score ~84</span>
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5">8 Failed attempts, Unknown Bot</p>
            </button>

            <button
              onClick={() => applyPreset("data-exfiltration")}
              className={`p-2 rounded-xl border text-left transition-all cursor-pointer ${
                activePreset === "data-exfiltration"
                  ? "bg-amber-950/40 border-amber-500/50 text-amber-300"
                  : "bg-slate-950/60 border-slate-800 text-slate-300 hover:border-slate-700"
              }`}
            >
              <div className="text-xs font-bold flex items-center justify-between">
                <span>Abnormal Exfiltration</span>
                <span className="text-[10px] text-amber-400 font-mono">Score ~62</span>
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5">4:00 AM, 1450 MB Download spike</p>
            </button>
          </div>
        </div>
      </div>

      {/* Vector Sliders & Parameters */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-5 shadow-xl space-y-4">
          <div className="flex items-center space-x-2">
            <Sliders className="w-4 h-4 text-teal-400" />
            <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">
              Live Feature Vector Controls
            </h3>
          </div>

          {/* L: Location */}
          <div className="space-y-1.5 bg-slate-950/60 p-3 rounded-xl border border-slate-800">
            <div className="flex justify-between text-xs">
              <span className="font-semibold text-slate-200">
                [L] Unusual Location Score (Weight: 25%)
              </span>
              <span className="font-mono text-teal-400 font-bold">
                {vector.locationChangeScore} / 100
              </span>
            </div>
            <input
              type="range"
              min="0"
              max="100"
              value={vector.locationChangeScore}
              onChange={(e) => {
                setActivePreset("custom");
                onVectorChange({ locationChangeScore: Number(e.target.value) });
              }}
              className="w-full accent-teal-400 cursor-pointer"
            />
            <div className="flex justify-between text-[11px] text-slate-400">
              <span>Location: {vector.locationName}</span>
              <span>{vector.distanceKm} km from baseline</span>
            </div>
          </div>

          {/* D: Device */}
          <div className="space-y-1.5 bg-slate-950/60 p-3 rounded-xl border border-slate-800">
            <div className="flex justify-between text-xs">
              <span className="font-semibold text-slate-200">
                [D] Unknown Device Score (Weight: 20%)
              </span>
              <span className="font-mono text-sky-400 font-bold">
                {vector.deviceScore} / 100
              </span>
            </div>
            <input
              type="range"
              min="0"
              max="100"
              value={vector.deviceScore}
              onChange={(e) => {
                setActivePreset("custom");
                onVectorChange({ deviceScore: Number(e.target.value) });
              }}
              className="w-full accent-sky-400 cursor-pointer"
            />
            <div className="text-[11px] text-slate-400">
              Hardware: <span className="text-slate-200">{vector.deviceName}</span>
            </div>
          </div>

          {/* F: Failed Attempts */}
          <div className="space-y-1.5 bg-slate-950/60 p-3 rounded-xl border border-slate-800">
            <div className="flex justify-between text-xs">
              <span className="font-semibold text-slate-200">
                [F] Failed Login Attempts (Weight: 20%)
              </span>
              <span className="font-mono text-amber-400 font-bold">
                {vector.failedLoginScore} / 100 ({vector.failedAttempts} attempts)
              </span>
            </div>
            <input
              type="range"
              min="0"
              max="10"
              value={vector.failedAttempts}
              onChange={(e) => {
                setActivePreset("custom");
                const attempts = Number(e.target.value);
                onVectorChange({
                  failedAttempts: attempts,
                  failedLoginScore: Math.min(100, attempts * 15),
                });
              }}
              className="w-full accent-amber-400 cursor-pointer"
            />
          </div>

          {/* T: Time */}
          <div className="space-y-1.5 bg-slate-950/60 p-3 rounded-xl border border-slate-800">
            <div className="flex justify-between text-xs">
              <span className="font-semibold text-slate-200">
                [T] Unusual Hour Score (Weight: 15%)
              </span>
              <span className="font-mono text-indigo-400 font-bold">
                {vector.unusualTimeScore} / 100 ({vector.loginHour}:00 hrs)
              </span>
            </div>
            <input
              type="range"
              min="0"
              max="23"
              value={vector.loginHour}
              onChange={(e) => {
                setActivePreset("custom");
                const h = Number(e.target.value);
                // Baseline hours: 9-23. Outside is unusual.
                const unusual = h >= 9 && h <= 23 ? 5 : (Math.abs(h - 16) / 12) * 100;
                onVectorChange({
                  loginHour: h,
                  unusualTimeScore: Math.round(unusual),
                });
              }}
              className="w-full accent-indigo-400 cursor-pointer"
            />
            <div className="text-[11px] text-slate-400">
              Normal user baseline active hours: 09:00 AM – 11:00 PM
            </div>
          </div>

          {/* B: Abnormal Behavior */}
          <div className="space-y-1.5 bg-slate-950/60 p-3 rounded-xl border border-slate-800">
            <div className="flex justify-between text-xs">
              <span className="font-semibold text-slate-200">
                [B] Abnormal Behavior Score (Weight: 20%)
              </span>
              <span className="font-mono text-rose-400 font-bold">
                {vector.abnormalBehaviorScore} / 100
              </span>
            </div>
            <input
              type="range"
              min="0"
              max="100"
              value={vector.abnormalBehaviorScore}
              onChange={(e) => {
                setActivePreset("custom");
                onVectorChange({ abnormalBehaviorScore: Number(e.target.value) });
              }}
              className="w-full accent-rose-400 cursor-pointer"
            />
            <div className="flex items-center space-x-3 text-[11px] text-slate-400">
              <label className="flex items-center space-x-1 cursor-pointer">
                <input
                  type="checkbox"
                  checked={vector.passwordChangeAttempt}
                  onChange={(e) =>
                    onVectorChange({ passwordChangeAttempt: e.target.checked })
                  }
                  className="rounded border-slate-700 text-teal-500 focus:ring-0"
                />
                <span>Password Change Attempt</span>
              </label>
              <label className="flex items-center space-x-1 cursor-pointer">
                <input
                  type="checkbox"
                  checked={vector.unusualFileAccess}
                  onChange={(e) =>
                    onVectorChange({ unusualFileAccess: e.target.checked })
                  }
                  className="rounded border-slate-700 text-teal-500 focus:ring-0"
                />
                <span>Unusual File Access</span>
              </label>
            </div>
          </div>

          {/* Trigger Alert Button */}
          <button
            onClick={onTriggerExplainableAlert}
            disabled={isAnalyzing}
            className="w-full py-2.5 rounded-xl bg-gradient-to-r from-teal-600 to-indigo-600 hover:from-teal-500 hover:to-indigo-500 text-white font-bold text-xs flex items-center justify-center space-x-2 shadow-lg shadow-teal-500/20 transition-all cursor-pointer disabled:opacity-50"
          >
            {isAnalyzing ? (
              <span className="flex items-center space-x-2">
                <span className="w-4 h-4 border-2 border-white/20 border-t-white rounded-full animate-spin" />
                <span>Generating Explainable AI Alert...</span>
              </span>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>Synthesize Explainable AI Alert</span>
              </>
            )}
          </button>
        </div>

        {/* Right: Synthetic Dataset Explorer (Section 5 from prompt) */}
        <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-5 shadow-xl flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center space-x-2">
                <Database className="w-4 h-4 text-sky-400" />
                <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">
                  Synthetic Dataset &amp; ML Records
                </h3>
              </div>
              <span className="text-[11px] text-slate-400">Section 5 Benchmark Data</span>
            </div>

            <p className="text-xs text-slate-400 mb-3">
              CyberShadow uses Isolation Forest &amp; K-Means clustering to classify telemetry into normal vs. suspicious clusters.
            </p>

            <div className="overflow-x-auto rounded-xl border border-slate-800">
              <table className="w-full text-[11px] text-left">
                <thead className="bg-slate-950 text-slate-400 font-mono uppercase text-[10px]">
                  <tr>
                    <th className="p-2">Hour</th>
                    <th className="p-2">Loc Δ</th>
                    <th className="p-2">New Dev</th>
                    <th className="p-2">Failed</th>
                    <th className="p-2">MB</th>
                    <th className="p-2">Pass Δ</th>
                    <th className="p-2">Label</th>
                    <th className="p-2">Anomaly Score</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800 font-mono">
                  {sampleSyntheticDataset.map((row, i) => (
                    <tr
                      key={i}
                      className={`hover:bg-slate-800/40 ${
                        row.risk_label === "suspicious" ? "bg-rose-950/20" : ""
                      }`}
                    >
                      <td className="p-2 text-slate-200">{row.login_hour}</td>
                      <td className="p-2 text-slate-300">{row.location_change}</td>
                      <td className="p-2 text-slate-300">{row.new_device}</td>
                      <td className="p-2 text-slate-300">{row.failed_attempts}</td>
                      <td className="p-2 text-slate-300">{row.data_download_mb}</td>
                      <td className="p-2 text-slate-300">{row.password_change}</td>
                      <td className="p-2">
                        <span
                          className={`px-1.5 py-0.5 rounded text-[9px] font-bold uppercase ${
                            row.risk_label === "suspicious"
                              ? "bg-rose-500/20 text-rose-300"
                              : "bg-emerald-500/20 text-emerald-300"
                          }`}
                        >
                          {row.risk_label}
                        </span>
                      </td>
                      <td className="p-2 text-slate-400">
                        {row.anomaly_score > 0 ? `+${row.anomaly_score}` : row.anomaly_score}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="mt-4 p-3 rounded-xl bg-slate-950/70 border border-slate-800 text-xs text-slate-300">
            <div className="flex items-center space-x-1.5 font-semibold text-teal-300 mb-1">
              <TrendingUp className="w-3.5 h-3.5" />
              <span>Mathematical Model Interpretation</span>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Isolation Forest computes path lengths in random trees; anomalous events (e.g. login at 3 AM from foreign IP with 5 failed attempts) isolate rapidly near tree roots, triggering high risk categorization before malicious lateral movement can succeed.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
