import React, { useState } from "react";
import {
  Search,
  AlertTriangle,
  ShieldCheck,
  ShieldAlert,
  Send,
  Sparkles,
  Link2,
  FileText,
  Mail,
  MessageSquare,
  Upload,
  CheckCircle,
  ExternalLink,
  Zap,
} from "lucide-react";
import { PhishingAnalysis, RiskLevel } from "../types";
import { samplePhishingTemplates } from "../data/cyberDefaults";

interface PhishingScannerProps {
  onScan: (params: { content: string; type: string; sender: string; url: string }) => Promise<void>;
  analysisResult: PhishingAnalysis | null;
  isScanning: boolean;
}

export const PhishingScanner: React.FC<PhishingScannerProps> = ({
  onScan,
  analysisResult,
  isScanning,
}) => {
  const [content, setContent] = useState<string>(samplePhishingTemplates[0].content);
  const [type, setType] = useState<string>("email");
  const [sender, setSender] = useState<string>(samplePhishingTemplates[0].sender);
  const [url, setUrl] = useState<string>(samplePhishingTemplates[0].url);
  const [selectedTemplateId, setSelectedTemplateId] = useState<string>("hackathon-sample");

  const handleSelectTemplate = (templateId: string) => {
    setSelectedTemplateId(templateId);
    const tmpl = samplePhishingTemplates.find((t) => t.id === templateId);
    if (tmpl) {
      setContent(tmpl.content);
      setType(tmpl.type);
      setSender(tmpl.sender);
      setUrl(tmpl.url);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onScan({ content, type, sender, url });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-5 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center space-x-2">
              <Search className="w-5 h-5 text-teal-400" />
              <h2 className="text-base font-bold text-white tracking-tight">
                AI Phishing, Scam &amp; Impersonation Detector
              </h2>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Inspect suspicious emails, SMS messages, fake URLs, and social engineering coercion with explainable AI.
            </p>
          </div>

          <div className="flex items-center space-x-2">
            <span className="text-xs text-slate-400">Standard:</span>
            <span className="text-xs font-semibold text-teal-300 bg-teal-500/10 px-2 py-0.5 rounded border border-teal-500/20">
              CISA Phishing-Resistant MFA Aligned
            </span>
          </div>
        </div>

        {/* Quick Sample Selector */}
        <div className="mt-4 pt-3 border-t border-slate-800">
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-2">
            Load Pre-Configured Threat Scenarios:
          </span>
          <div className="flex flex-wrap gap-2">
            {samplePhishingTemplates.map((tmpl) => (
              <button
                key={tmpl.id}
                onClick={() => handleSelectTemplate(tmpl.id)}
                className={`px-3 py-1.5 rounded-xl border text-xs font-medium transition-all cursor-pointer ${
                  selectedTemplateId === tmpl.id
                    ? "bg-teal-500/20 border-teal-500/40 text-teal-300 shadow-sm"
                    : "bg-slate-950/60 border-slate-800 text-slate-300 hover:border-slate-700"
                }`}
              >
                {tmpl.name}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left: Input Form */}
        <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-5 shadow-xl">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">
                Suspicious Message Details
              </h3>
              <div className="flex space-x-1">
                <button
                  type="button"
                  onClick={() => setType("email")}
                  className={`px-2 py-1 text-xs rounded-md ${
                    type === "email" ? "bg-teal-500 text-slate-950 font-bold" : "text-slate-400 bg-slate-800"
                  }`}
                >
                  Email
                </button>
                <button
                  type="button"
                  onClick={() => setType("sms")}
                  className={`px-2 py-1 text-xs rounded-md ${
                    type === "sms" ? "bg-teal-500 text-slate-950 font-bold" : "text-slate-400 bg-slate-800"
                  }`}
                >
                  SMS
                </button>
                <button
                  type="button"
                  onClick={() => setType("url")}
                  className={`px-2 py-1 text-xs rounded-md ${
                    type === "url" ? "bg-teal-500 text-slate-950 font-bold" : "text-slate-400 bg-slate-800"
                  }`}
                >
                  URL Only
                </button>
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Sender Identity / Address (Email header or Phone number)
              </label>
              <input
                type="text"
                value={sender}
                onChange={(e) => setSender(e.target.value)}
                placeholder="e.g. support@university-security.online"
                className="w-full bg-slate-950/80 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-teal-500 font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Embedded URL / Target Link
              </label>
              <div className="flex items-center space-x-2">
                <Link2 className="w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                  placeholder="e.g. http://college-login-security.example"
                  className="w-full bg-slate-950/80 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-teal-500 font-mono"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Message Body or OCR Text from Screenshot
              </label>
              <textarea
                rows={6}
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="Paste the raw email text, SMS message, or notification here..."
                className="w-full bg-slate-950/80 border border-slate-800 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-teal-500 font-mono leading-relaxed"
              />
            </div>

            <button
              type="submit"
              disabled={isScanning}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-teal-600 to-indigo-600 hover:from-teal-500 hover:to-indigo-500 text-white font-bold text-xs flex items-center justify-center space-x-2 shadow-lg shadow-teal-500/20 transition-all cursor-pointer disabled:opacity-50"
            >
              {isScanning ? (
                <span className="flex items-center space-x-2">
                  <span className="w-4 h-4 border-2 border-white/20 border-t-white rounded-full animate-spin" />
                  <span>Scanning with AI Model &amp; Domain Heuristics...</span>
                </span>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Run AI Phishing &amp; Coercion Scan</span>
                </>
              )}
            </button>
          </form>
        </div>

        {/* Right: Analysis Results & CISA Guidance */}
        <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-5 shadow-xl flex flex-col justify-between">
          {analysisResult ? (
            <div className="space-y-4">
              {/* Verdict Banner */}
              <div
                className={`p-4 rounded-xl border flex items-center justify-between ${
                  analysisResult.riskLevel === "Critical"
                    ? "bg-rose-950/30 border-rose-500/40 text-rose-300"
                    : analysisResult.riskLevel === "High"
                    ? "bg-orange-950/30 border-orange-500/40 text-orange-300"
                    : analysisResult.riskLevel === "Medium"
                    ? "bg-amber-950/30 border-amber-500/40 text-amber-300"
                    : "bg-emerald-950/30 border-emerald-500/40 text-emerald-300"
                }`}
              >
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider block">
                    AI Threat Evaluation
                  </span>
                  <h3 className="text-lg font-bold font-mono">
                    {analysisResult.riskLevel.toUpperCase()} RISK: {analysisResult.riskScore}/100
                  </h3>
                  <p className="text-xs mt-1 text-slate-300">{analysisResult.summary}</p>
                </div>
              </div>

              {/* Indicator Breakdown */}
              <div>
                <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
                  Detected Threat Indicators:
                </h4>
                <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                  {analysisResult.indicators.map((ind, i) => (
                    <div
                      key={i}
                      className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800 text-xs"
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-bold text-slate-200">{ind.flag}</span>
                        <span
                          className={`text-[9px] font-bold uppercase px-1.5 py-0.5 rounded ${
                            ind.severity === "critical"
                              ? "bg-rose-500/20 text-rose-300"
                              : ind.severity === "high"
                              ? "bg-orange-500/20 text-orange-300"
                              : "bg-amber-500/20 text-amber-300"
                          }`}
                        >
                          {ind.severity}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400">{ind.explanation}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Recommended Actions (CISA Phishing-Resistant MFA) */}
              <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-800">
                <div className="flex items-center space-x-1.5 text-xs font-bold text-teal-300 mb-2">
                  <Zap className="w-3.5 h-3.5 text-teal-400" />
                  <span>CISA Recommended Incident Actions:</span>
                </div>
                <ul className="space-y-1.5 text-xs text-slate-300">
                  {analysisResult.recommendedActions.map((action, i) => (
                    <li key={i} className="flex items-start space-x-2">
                      <span className="w-4 h-4 rounded-full bg-teal-500/20 text-teal-300 flex items-center justify-center shrink-0 text-[10px] mt-0.5">
                        {i + 1}
                      </span>
                      <span>{action}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Shadow simulation preview */}
              {analysisResult.shadowSimulation && (
                <div className="p-2.5 rounded-lg bg-indigo-950/20 border border-indigo-500/30 text-[11px] text-indigo-200">
                  <span className="font-bold text-indigo-300 block mb-0.5">
                    Estimated Blast Radius:
                  </span>
                  {analysisResult.shadowSimulation.potentialBlastRadius}
                </div>
              )}
            </div>
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-500">
              <Search className="w-12 h-12 mb-3 stroke-1 text-slate-600" />
              <p className="text-sm text-slate-400 font-medium">Ready to Analyze</p>
              <p className="text-xs text-slate-500 mt-1 max-w-xs">
                Select a sample scenario or enter custom text to see AI decomposition of phishing patterns.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
