import React from "react";
import { Shield, ShieldAlert, ShieldCheck, AlertTriangle, Info, HelpCircle } from "lucide-react";
import { RiskLevel, RiskCalculationBreakdown } from "../types";

interface RiskScoreGaugeProps {
  score: number;
  breakdown?: RiskCalculationBreakdown;
  categoryScores: {
    identity: number;
    device: number;
    account: number;
    network: number;
  };
  onSimulateAttack?: () => void;
}

export const RiskScoreGauge: React.FC<RiskScoreGaugeProps> = ({
  score,
  breakdown,
  categoryScores,
  onSimulateAttack,
}) => {
  // Score interpretation: 0-25 Low, 26-50 Moderate, 51-75 High, 76-100 Critical
  let riskLevel: RiskLevel = "Low";
  let colorClass = "text-emerald-400";
  let bgClass = "bg-emerald-500/10 border-emerald-500/30";
  let strokeColor = "#10b981"; // emerald

  if (score >= 76) {
    riskLevel = "Critical";
    colorClass = "text-rose-400";
    bgClass = "bg-rose-500/10 border-rose-500/30";
    strokeColor = "#f43f5e"; // rose
  } else if (score >= 51) {
    riskLevel = "High";
    colorClass = "text-orange-400";
    bgClass = "bg-orange-500/10 border-orange-500/30";
    strokeColor = "#f97316"; // orange
  } else if (score >= 26) {
    riskLevel = "Medium";
    colorClass = "text-amber-400";
    bgClass = "bg-amber-500/10 border-amber-500/30";
    strokeColor = "#f59e0b"; // amber
  }

  // Circular gauge calculations (circumference for r=70 is 439.82)
  const radius = 68;
  const circumference = 2 * Math.PI * radius;
  // We use a 240-degree arc gauge
  const arcLength = circumference * (240 / 360);
  const strokeDashoffset = arcLength - (arcLength * Math.min(100, Math.max(0, score))) / 100;

  return (
    <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-5 shadow-xl backdrop-blur">
      <div className="flex flex-col lg:flex-row items-center justify-between gap-6">
        {/* Left: Main Circular Gauge */}
        <div className="flex flex-col items-center text-center">
          <div className="relative w-48 h-48 flex items-center justify-center">
            {/* SVG Arc */}
            <svg className="w-full h-full transform -rotate-120" viewBox="0 0 160 160">
              {/* Background track */}
              <circle
                cx="80"
                cy="80"
                r={radius}
                fill="transparent"
                stroke="#1e293b"
                strokeWidth="12"
                strokeDasharray={arcLength}
                strokeDashoffset="0"
                strokeLinecap="round"
              />
              {/* Foreground colored arc */}
              <circle
                cx="80"
                cy="80"
                r={radius}
                fill="transparent"
                stroke={strokeColor}
                strokeWidth="12"
                strokeDasharray={arcLength}
                strokeDashoffset={strokeDashoffset}
                strokeLinecap="round"
                className="transition-all duration-700 ease-out"
              />
            </svg>

            {/* Central Score Value */}
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-4xl font-extrabold tracking-tight text-white font-mono">
                {score}
              </span>
              <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                out of 100
              </span>
              <div className={`mt-1.5 px-2.5 py-0.5 rounded-full text-xs font-bold border ${bgClass} ${colorClass}`}>
                {riskLevel.toUpperCase()} RISK
              </div>
            </div>
          </div>

          <div className="mt-2 text-center">
            <h3 className="text-sm font-semibold text-slate-200">Personal Cyber Risk Score</h3>
            <p className="text-xs text-slate-400 max-w-xs mt-0.5">
              Learned baseline vs. current session behavioral deviations.
            </p>
          </div>
        </div>

        {/* Middle: Formula & Component Weights */}
        <div className="flex-1 w-full bg-slate-950/60 rounded-xl p-4 border border-slate-800/80">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center space-x-2">
              <Shield className="w-4 h-4 text-teal-400" />
              <span className="text-xs font-semibold text-slate-200 uppercase tracking-wider font-mono">
                Dynamic Formula Breakdown
              </span>
            </div>
            <span className="text-[11px] text-slate-400 font-mono">
              0.25L + 0.20D + 0.20F + 0.15T + 0.20B
            </span>
          </div>

          {breakdown ? (
            <div className="space-y-2 text-xs">
              <div className="flex items-center justify-between text-slate-300">
                <span className="flex items-center space-x-1.5">
                  <span className="w-4 font-mono font-bold text-teal-400">L</span>
                  <span>Unusual Location (25%)</span>
                </span>
                <span className="font-mono text-slate-400">
                  {breakdown.components.L.rawScore}/100 →{" "}
                  <strong className="text-slate-200">{breakdown.components.L.weightedScore} pts</strong>
                </span>
              </div>
              <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                <div
                  className="bg-teal-500 h-full rounded-full transition-all duration-500"
                  style={{ width: `${breakdown.components.L.rawScore}%` }}
                />
              </div>

              <div className="flex items-center justify-between text-slate-300">
                <span className="flex items-center space-x-1.5">
                  <span className="w-4 font-mono font-bold text-sky-400">D</span>
                  <span>Unknown Device (20%)</span>
                </span>
                <span className="font-mono text-slate-400">
                  {breakdown.components.D.rawScore}/100 →{" "}
                  <strong className="text-slate-200">{breakdown.components.D.weightedScore} pts</strong>
                </span>
              </div>
              <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                <div
                  className="bg-sky-500 h-full rounded-full transition-all duration-500"
                  style={{ width: `${breakdown.components.D.rawScore}%` }}
                />
              </div>

              <div className="flex items-center justify-between text-slate-300">
                <span className="flex items-center space-x-1.5">
                  <span className="w-4 font-mono font-bold text-amber-400">F</span>
                  <span>Failed Logins (20%)</span>
                </span>
                <span className="font-mono text-slate-400">
                  {breakdown.components.F.rawScore}/100 →{" "}
                  <strong className="text-slate-200">{breakdown.components.F.weightedScore} pts</strong>
                </span>
              </div>
              <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                <div
                  className="bg-amber-500 h-full rounded-full transition-all duration-500"
                  style={{ width: `${breakdown.components.F.rawScore}%` }}
                />
              </div>

              <div className="flex items-center justify-between text-slate-300">
                <span className="flex items-center space-x-1.5">
                  <span className="w-4 font-mono font-bold text-indigo-400">T</span>
                  <span>Unusual Time (15%)</span>
                </span>
                <span className="font-mono text-slate-400">
                  {breakdown.components.T.rawScore}/100 →{" "}
                  <strong className="text-slate-200">{breakdown.components.T.weightedScore} pts</strong>
                </span>
              </div>
              <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                <div
                  className="bg-indigo-500 h-full rounded-full transition-all duration-500"
                  style={{ width: `${breakdown.components.T.rawScore}%` }}
                />
              </div>

              <div className="flex items-center justify-between text-slate-300">
                <span className="flex items-center space-x-1.5">
                  <span className="w-4 font-mono font-bold text-rose-400">B</span>
                  <span>Abnormal Behavior (20%)</span>
                </span>
                <span className="font-mono text-slate-400">
                  {breakdown.components.B.rawScore}/100 →{" "}
                  <strong className="text-slate-200">{breakdown.components.B.weightedScore} pts</strong>
                </span>
              </div>
              <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                <div
                  className="bg-rose-500 h-full rounded-full transition-all duration-500"
                  style={{ width: `${breakdown.components.B.rawScore}%` }}
                />
              </div>
            </div>
          ) : (
            <p className="text-xs text-slate-400">Formula breakdown updating dynamically...</p>
          )}
        </div>

        {/* Right: Four Pillar Health Scores */}
        <div className="w-full lg:w-64 grid grid-cols-2 gap-2.5">
          <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800">
            <span className="text-[10px] uppercase font-semibold text-slate-400 tracking-wider">Identity</span>
            <div className="text-lg font-bold text-white font-mono mt-0.5">{categoryScores.identity}%</div>
            <span className="text-[11px] text-emerald-400">MFA Enforced</span>
          </div>

          <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800">
            <span className="text-[10px] uppercase font-semibold text-slate-400 tracking-wider">Device</span>
            <div className="text-lg font-bold text-white font-mono mt-0.5">{categoryScores.device}%</div>
            <span className="text-[11px] text-teal-400">2 Known Hardware</span>
          </div>

          <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800">
            <span className="text-[10px] uppercase font-semibold text-slate-400 tracking-wider">Account</span>
            <div className="text-lg font-bold text-white font-mono mt-0.5">{categoryScores.account}%</div>
            <span className="text-[11px] text-amber-400">1 Reused Pass</span>
          </div>

          <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800">
            <span className="text-[10px] uppercase font-semibold text-slate-400 tracking-wider">Network</span>
            <div className="text-lg font-bold text-white font-mono mt-0.5">{categoryScores.network}%</div>
            <span className="text-[11px] text-sky-400">Campus Eduroam</span>
          </div>
        </div>
      </div>
    </div>
  );
};
