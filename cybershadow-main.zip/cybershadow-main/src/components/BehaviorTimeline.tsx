import React, { useState } from "react";
import { Clock, ShieldCheck, AlertTriangle, ShieldAlert, Laptop, Smartphone, Globe, ArrowRight } from "lucide-react";
import { ActivityEvent } from "../types";

interface BehaviorTimelineProps {
  events: ActivityEvent[];
}

export const BehaviorTimeline: React.FC<BehaviorTimelineProps> = ({ events }) => {
  const [filter, setFilter] = useState<"all" | "suspicious" | "normal">("all");

  const filteredEvents = events.filter((e) => {
    if (filter === "suspicious") return e.status !== "normal";
    if (filter === "normal") return e.status === "normal";
    return true;
  });

  return (
    <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-5 shadow-xl">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5">
        <div>
          <h3 className="text-base font-bold text-white tracking-tight flex items-center space-x-2">
            <Clock className="w-5 h-5 text-teal-400" />
            <span>Behavior Timeline &amp; Circadian Activity</span>
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Learned temporal rhythm vs. real-time telemetry events
          </p>
        </div>

        {/* Filter chips */}
        <div className="flex items-center space-x-1.5 bg-slate-950/70 p-1 rounded-lg border border-slate-800">
          <button
            onClick={() => setFilter("all")}
            className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
              filter === "all" ? "bg-teal-500 text-slate-950" : "text-slate-400 hover:text-slate-200"
            }`}
          >
            All ({events.length})
          </button>
          <button
            onClick={() => setFilter("suspicious")}
            className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
              filter === "suspicious" ? "bg-rose-500 text-white" : "text-slate-400 hover:text-slate-200"
            }`}
          >
            Anomalous ({events.filter((e) => e.status !== "normal").length})
          </button>
          <button
            onClick={() => setFilter("normal")}
            className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
              filter === "normal" ? "bg-emerald-600 text-white" : "text-slate-400 hover:text-slate-200"
            }`}
          >
            Normal ({events.filter((e) => e.status === "normal").length})
          </button>
        </div>
      </div>

      {/* Visual Timeline Stream */}
      <div className="relative pl-6 border-l-2 border-slate-800 space-y-5 my-2">
        {filteredEvents.map((evt) => {
          const isSuspicious = evt.status !== "normal";

          return (
            <div key={evt.id} className="relative group">
              {/* Timeline marker node */}
              <div
                className={`absolute -left-[31px] top-1.5 w-4 h-4 rounded-full border-2 border-slate-900 flex items-center justify-center ${
                  isSuspicious
                    ? "bg-rose-500 ring-4 ring-rose-500/20"
                    : "bg-emerald-500 ring-4 ring-emerald-500/20"
                }`}
              />

              <div
                className={`p-3.5 rounded-xl border transition-all ${
                  isSuspicious
                    ? "bg-rose-950/20 border-rose-500/30"
                    : "bg-slate-950/60 border-slate-800/80 hover:border-slate-700"
                }`}
              >
                <div className="flex flex-wrap items-center justify-between gap-2 mb-1.5">
                  <div className="flex items-center space-x-2">
                    <span className="text-xs font-bold text-slate-100">{evt.event}</span>
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase ${
                        isSuspicious
                          ? "bg-rose-500/20 text-rose-300 border border-rose-500/30"
                          : "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30"
                      }`}
                    >
                      {evt.status} (Score: {evt.riskScore})
                    </span>
                  </div>
                  <span className="text-[11px] text-slate-400 font-mono">{evt.timestamp}</span>
                </div>

                <p className="text-xs text-slate-300 mb-2">{evt.details}</p>

                <div className="flex flex-wrap items-center gap-3 text-[11px] text-slate-400">
                  <span className="flex items-center space-x-1">
                    <Globe className="w-3.5 h-3.5 text-teal-400" />
                    <span>{evt.location}</span>
                  </span>
                  <span className="flex items-center space-x-1">
                    <Laptop className="w-3.5 h-3.5 text-sky-400" />
                    <span>{evt.device}</span>
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
